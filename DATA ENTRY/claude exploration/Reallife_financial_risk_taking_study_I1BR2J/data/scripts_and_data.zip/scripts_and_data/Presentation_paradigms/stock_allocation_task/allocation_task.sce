pcl_file = "allocation_task.pcl";
scenario = "allocation_task";

scenario_type = fMRI_emulation;
pulses_per_scan = 1;
scan_period = 2500;
pulse_code = 1;

active_buttons = 4;
button_codes = 1, 2, 3, 4; # L index, R index, L thumb, R thumb
target_button_codes = 101, 102, 103, 104; #?

response_matching = simple_matching;

default_font = "Arial";
default_font_size = 40;
default_picture_duration = 200;

default_background_color = 0, 0, 0;
default_text_color = 255,255,255;

begin;

### ==============================================================
### trial definitions
### ==============================================================

### pause trial
trial {
	trial_duration = 250;
	picture{text {caption = "+"; font_size=40;}; center_x  = 0; center_y = 0;	};
	duration = next_picture;
	time = 0;
	code = "Pause";
} pause_trial;

### instruction trial & button test
### -------------------------------
bitmap { filename = "button_hands.bmp"; scale_factor = 1; transparent_color= 0, 0, 0;} bmp_button_hands;

array {
	picture{bitmap { filename = "instr1.bmp"; scale_factor = 1;}; center_x = 0; center_y =0; };
	picture{bitmap { filename = "instr2.bmp"; scale_factor = 1;}; center_x = 0; center_y =0;};
	picture{bitmap { filename = "instr3.bmp"; scale_factor = 1;}; center_x = 0; center_y =0;};
	picture {text {caption = "Um Ihren Einsatz einzugeben,\nstehen Ihnen folgende Tasten zur Verfügung:";
					text_align = align_center; font_size = 18; }; x = 0; y = 100; 
				bitmap bmp_button_hands; x = 0; y = -100;
				text {caption = "Weiter mit Taste...";
						text_align = align_center; font_size = 18; }; x = 0; y = -250;};
}bmp_instr;


### button training trial
### ---------------------
text {caption = "Hier steht Text.";
		text_align = align_center; font_size = 18; }picpart_ex;
text {caption="0 €"; font_size = 30;}picpart_input;	#placeholder 

trial{
   trial_type = first_response;
   trial_duration = forever;
	stimulus_event{
		picture {text picpart_ex; x=0;y=100;
					text picpart_input; x=0;y=0;
					bitmap bmp_button_hands; x=0; y=-100;};
					time=0;
					duration = 10000;
					response_active=true;}example;
}training_trial; 

trial {
	trial_type = fixed;
	stimulus_event {
		picture {text{caption="OK"; font_size=30;}; x = 0; y = 0;};
					duration = 1000;
					response_active = true;};
} ok_trial;


### choice trial
### ------------

# placeholder picture parts for choice_pic
text {caption = " "; font_size=20;}picpart_riskyhival;	
text {caption = " ";font_size=20;}picpart_riskyloval;	
text {caption = " ";font_size=20;}picpart_safeval;		
#text {caption = "+";}picpart_cross;			
text {caption = "Aktie";font_size=20;}picpart_risky;			
text {caption = "Anleihe";font_size=20;}picpart_safe;
text {caption = " ";font_size=20;}picpart_max;
text {caption = " ";font_size=20;}picpart_invest;
bitmap { filename = "frame.bmp"; height = 40; width =300; 
			transparent_color = 0,0,0;} bmp_frame;#black is transparent
   
picture {
	text picpart_risky;				# ganz oben links
	center_x = -100; center_y = 100;

	text picpart_riskyhival;		# oben links
	center_x = -100; center_y = 50;
	
	text picpart_riskyloval;		# unten links
	center_x = -100; center_y = 0;		

	text picpart_safe;				# ganz oben rechts
	center_x = 100; center_y = 100;
	
	text picpart_safeval;			# oben rechts
	center_x = 100; center_y = 50;		
	
	#text picpart_cross;				# mittig
	#center_x  = 0; center_y = 0;	

	text picpart_max;
	center_x  = 0; center_y = -80;	
	
	text picpart_invest;
	center_x  = 0; center_y = -120;	
}choice_pic;

trial{
   trial_type = first_response;
   trial_duration = forever;
   stimulus_event{
		picture choice_pic;
					time = 0;
					duration = 20000;
					response_active = true;};
}choice_trial;


### ==============================================================
### placeholder trials to be replaced in pcl
### ==============================================================
text {
   caption = " "; font_size = 50; font_color = 255, 255, 255; text_align = align_center;
} text_add;

picture {} default;

### empty trials
picture { } slide_pic;
trial {
	trial_duration = 100;
	stimulus_event { 
				picture slide_pic;
				time = 0;
				duration = next_picture;
				response_active = true;
				target_button = 1;
			} slide_stimulus;
} slide_trial;

trial {
	trial_duration = 100;
	stimulus_event { 
				picture default;
				time = 0;
				duration = next_picture;
				response_active = true;	
				code = 10;	
			} picture_stimulus;
} picture_trial;

picture { # box white_box; x = 0; y = 0; box grey_box; x = 0; y = 0;
          text {caption = "hallo"; font_size = 5; } message_text; x = 0; y = 0;} message_pic;

trial {
	trial_duration = 100;
	stimulus_event { 
				picture message_pic;
				time = 0;
				duration = next_picture;
				response_active = true;		
				code = 1;	
			} message_stimulus;
} message_trial;

trial {
	trial_duration = 2000;
	picture {};
	duration = next_picture;
	time = 0;
	code = "blank";
} blank_trial;