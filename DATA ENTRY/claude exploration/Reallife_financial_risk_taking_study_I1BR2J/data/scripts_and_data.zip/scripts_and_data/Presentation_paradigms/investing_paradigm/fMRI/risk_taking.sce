pcl_file = "risk_taking.pcl";
scenario = "risk_taking";

scenario_type = fMRI;#_emulation;
pulses_per_scan = 1;
scan_period = 2500;
pulse_code = 1;

# Button A 1 left index
# Button C 2 right index
# Button B 3 left thumb
# Button D 4 right thumb
active_buttons = 4;
button_codes = 1, 2, 3, 4;
target_button_codes = 101, 102, 103, 104; #?

response_matching = simple_matching;

default_font = "Arial";
default_font_size = 40;
default_picture_duration = 200;

default_background_color = 0, 0, 0;
default_text_color = 255,255,255;

begin;


picture { text { caption = "+"; font_size = 40; }; x=0; y=0; } default;

# welcome & goodbye
#----------------------------------------------------
array {
	text { caption = "Herzlich willkommen zum Börsenspiel!\n\nBitte drücken Sie jetzt einen Knopf..."; font_size = 18; };
	text { caption = "Vielen Dank! \nDiese Untersuchung ist nun zu Ende.\n\nWir bitten um etwas Geduld,\nes wird sich gleich jemand melden."; font_size = 18; };
} welcome;


# instructions
#----------------------------------------------------
bitmap { filename = "instructions.bmp"; scale_factor = 1; } bmp_instructions;
picture { bitmap bmp_instructions; x=0; y=0; } instructions_pic;

# investment screen
#----------------------------------------------------
# placeholder picture parts for invest_pic
text { caption = "Aktie";font_size=20;}picpart_txtstock;
text { caption = "Anleihe";font_size=20;}picpart_txtbond;
text { caption = " "; font_size=22;}picpart_stockpayhi;	
text { caption = " ";font_size=22;}picpart_stockpaylo;	
text { caption = " ";font_size=22;}picpart_bondpay;	
text { caption = "+";}picpart_cross;			
bitmap {	filename = "frame.bmp"; height = 160; width =80; 
			transparent_color = 0,0,0;} bmp_frame;#black is transparent
bitmap {	filename = "frame_fb.bmp"; height = 160; width=80;
			transparent_color = 0,0,0;} bmp_frame_fb;#black is transparent
   
picture {
	#text picpart_cross;
	#center_x  = 0; center_y = 0;	

	bitmap bmp_frame;
	center_x = 80; center_y = 0;	

	bitmap bmp_frame;
	center_x = -80; center_y = 0;			

}invest_pic;


trial{
   trial_type = first_response;
   trial_duration = 6000;#forever;
   stimulus_event{
		picture invest_pic;
					time = 0;
					duration = 20000;
					response_active = true;}invest_stimulus;
}invest_trial;


# estimation screen
#----------------------------------------------------
box { height = 45; width = 8; color = 255,255,0;}controller;
bitmap { filename = "button_hands.bmp"; scale_factor = 1; transparent_color = 0, 0, 0;} bmp_button_hands;

text {caption = " ";font_color = 255,255,0; font_size=22;}picpart_estimVal;	

picture { text { caption = " "; font_size = 18; }picpart_title; center_x=0; center_y=100;
			 text { caption = "0"; font_size = 22; }; right_x=-210; center_y=0;
			 text { caption = "100 %"; font_size = 22; }; left_x=210; center_y=0;
			 box { height = 8; width = 400; color = 255,255,255; }; center_x=0; center_y=0;
			 box { height = 5; width = 395; color = 0,0,0; }; center_x=0; center_y=0;
			 text picpart_estimVal; center_x=0; center_y=-50;
			} estim_pic;

trial{
   trial_type = first_response;
   trial_duration = forever;
   stimulus_event{
		picture estim_pic;
					time = 0;
					duration = 20000;
					response_active = true;}estim_stimulus;
}estim_trial;


# empty placeholder objects
#----------------------------------------------------
trial {
	trial_duration = 100;
	stimulus_event { 
				picture default;
				time = 0;
				duration = next_picture;
				response_active = true;	
				code = 10;	
			} picture_stimulus;
} picture_trial;

picture { # box white_box; x = 0; y = 0; box grey_box; x = 0; y = 0;
          text {caption = "hallo"; font_size = 5; } message_text; x = 0; y = 0;} message_pic;

trial {
	trial_duration = 100;
	stimulus_event { 
				picture message_pic;
				time = 0;
				duration = next_picture;
				response_active = true;		
				code = 1;	
			} message_stimulus;
} message_trial;


trial {
	trial_duration = 2000;
	picture {};
	duration = next_picture;
	time = 0;
	code = "blank";
} blank_trial;


trial {
	trial_duration = 2000;
	picture default;
	duration = next_picture;
	time = 0;
	code = 2;
} pause_trial;
