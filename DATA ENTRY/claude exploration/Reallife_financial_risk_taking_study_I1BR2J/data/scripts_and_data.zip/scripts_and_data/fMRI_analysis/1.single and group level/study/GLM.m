% Script created by Sarah Rudorf and Alexander Niklas H�usler
%
% Script for setting up and estimating a GLM
%
% Script run in SPM12: v6470 in Matlab R2014a, on macOS Sierra 10.12.3
% The folder setup was as follows:
% - primary folder was called "study"
% - "study" contained this glm script, the "makedesignmatrix" folder, the
% "logfiles" folder, and the "_data" folder
% - in the "data" folder, there was a folder for each participant,
% containing another "_data" folder with the preprocessed volumes
% - Additionally, there was the "parameters.txt" file with the movement
% data in each participant folder
%
%
% NOTE:
% - script calls function makeSPMdesignmatrix that needs to be located in the 
%   directory specified (see the appropriate lines of code at the end of
%   the program)
% - script sets up GLM with onset regressors, modulated parameters and user
%   specified covariates (in this case the amount of payoff at payoff feedback)
% - calls function makeSPMdesignmatrix(filestr,ons,ons_name,ons_duration,ons_modulate,cov,cov_name);
% - default registry for 1st level data has to be adjusted each time
% (depending on use on Windows/Linux/Mac)
%
% Please note: all places where another researcher has to adjust the script
% are marked by "-->Adjust!!!"
% _______________________________________________________________________

clear variables;

cononly = 0; %this makes it possible to redo just the contrasts (set it to 1),
%if it is not desired to redo the GLM every time when new contrasts hare made

%========================================================================
% SET list of subjects & study parameters
%------------------------------------------------------------------------

% spmdir = 'SPM12';

    % study directory -->Adjust!!!
    studydir = '/.../study';
  
    addpath ([ studydir filesep 'makedesignmatrix']); % so SPM finds the makeSPMdesignmatrix file

    % folder name to save the SPM.mat in 
    outputname = 'GLM';

    % list of sessions; folders that contain your volumes:
    SubjectSession = {'_data'};

    % get list of subject directory names:
    subjFolder=dir([ studydir filesep '_data' filesep '*']);
    subjFolder=subjFolder([subjFolder.isdir]==1);
    subjFolder={subjFolder(:).name};
    subj_ids=subjFolder(~ismember(subjFolder,{'.','..'}));

for subno=1:length(subj_ids);     %this loops over subjects

    % get subject's ID (string before the first ^)
    subdir=([studydir filesep '_data' filesep subj_ids{subno} ]);
    outputdir = ([subdir filesep outputname ]);   
    subj_id=subj_ids{subno};
    
if ~cononly
    
% check if glm already exists    
if ~exist([outputdir filesep 'SPM.mat'],'file')

    cd (subdir);

%========================================================================
% SET subject-specific onset vectors etc.
%------------------------------------------------------------------------

    % Import vectors from textfile and read into workspace (this is where
    % the logfiles are located)
    addpath ([ studydir filesep 'logfiles']); % so SPM finds the logfiles folder
    fileToRead = dir(['/.../study/logfiles' filesep num2str(subj_id) '^risk_taking.txt']); %-->Adjust!!!
    rawData = importdata(fileToRead.name, '\t', 34);
    for i=8:34;
        eval(char(rawData(i))); 
    end

%========================================================================
% Regressors from the logfile that are relevant for this GLM:
%------------------------------------------------------------------------

% BLOCK CONDITIONS
% condition = 1=gainlo, 2=gainhi, 3=losslo, 4=losshi;

% CHOICE
% choice_onset
% choice = 1=stock, 2=bond
% choice_RT = choice duration

% OUTCOME
% stock_payoffPT = stock payoff onset
% payoff = actual payoff
% gain_loss = signals whether having made the correct or wrong choice

% ESTIMATION/EXPLICIT LEARNING
% estimPT = estimation onset

% TOTAL PAYOFF
% payoff_sumPT = payoff sum onset

%========================================================================
% DEFINE CONDITIONS
%------------------------------------------------------------------------

    % define names for all the conditions
    %------------------------------------

    ons_name{1}='stim_gain_stock'; 
    ons_name{2}='stim_gain_bond';
    ons_name{3}='stim_loss_stock';
    ons_name{4}='stim_loss_bond'; 
    ons_name{5}='pf_gain_stock_good';
    ons_name{6}='pf_gain_stock_bad';
    ons_name{7}='pf_gain_bond_good'; 
    ons_name{8}='pf_gain_bond_bad'; 
    ons_name{9}='pf_loss_stock_good';
    ons_name{10}='pf_loss_stock_bad';
    ons_name{11}='pf_loss_bond_good';
    ons_name{12}='pf_loss_bond_bad';
    ons_name{13}='estim_gain';
    ons_name{14}='estim_loss';
    ons_name{15}='sum_gain';
    ons_name{16}='sum_loss';

for sessno=1:length(SubjectSession) % loop over sessions
    
    % define onset times
    %--------------------
    temp1 = condition;
    temp2 = choice_onset;
    temp3 = choice;  
    temp4 = stock_payoffPT;
    temp5 = payoff;
    temp6 = estimPT;
    temp7 = payoff_sumPT;
    temp8 = choice_RT;
    temp9 = gain_loss;
    
    % ons{j,i} with ons_name j and session i
    % divide all regressors into gain/loss
    ons{1,sessno} = [];
    ons{2,sessno} = [];
    ons{3,sessno} = [];
    ons{4,sessno} = [];
    
    for j=1:length(temp1)
      if temp1(j)== 1 || temp1(j)== 2;
          if temp3(j)==1
          ons{1,sessno}=[ons{1,sessno} temp2(j)];
          else
          ons{2,sessno}=[ons{2,sessno} temp2(j)];
          end;
      else
          if temp3(j)==1
          ons{3,sessno}=[ons{3,sessno} temp2(j)];
          else
          ons{4,sessno}=[ons{4,sessno} temp2(j)];
          end;
      end;
    end;
    
    ons{5,sessno} = [];
    ons{6,sessno} = [];
    ons{7,sessno} = [];
    ons{8,sessno} = [];
    ons{9,sessno} = [];
    ons{10,sessno} = [];
    ons{11,sessno} = [];
    ons{12,sessno} = [];
        
    % current trial's payoff as modulator
    trial_payoff_pf_gain_stock_good=[]; 
    trial_payoff_pf_gain_stock_bad=[];  
    trial_payoff_pf_gain_bond_good=[];  
    trial_payoff_pf_gain_bond_bad=[];   
    trial_payoff_pf_loss_stock_good=[]; 
    trial_payoff_pf_loss_stock_bad=[];  
    trial_payoff_pf_loss_bond_good=[];  
    trial_payoff_pf_loss_bond_bad=[];   
    
    for j=1:length(temp1)
      if temp1(j)== 1 || temp1(j)== 2;
          if temp3(j)==1;
               if temp9(j)== 4 || temp9(j)==6;
               ons{5,sessno}=[ons{5,sessno} temp4(j)];
               trial_payoff_pf_gain_stock_good = [trial_payoff_pf_gain_stock_good temp5(j)]; 
               else
               ons{6,sessno}=[ons{6,sessno} temp4(j)];
               trial_payoff_pf_gain_stock_bad = [trial_payoff_pf_gain_stock_bad temp5(j)]
               end;
          else
               if temp9(j)== 4 || temp9(j)==6;
               ons{7,sessno}=[ons{7,sessno} temp4(j)];
               trial_payoff_pf_gain_bond_good = [trial_payoff_pf_gain_bond_good temp5(j)]
               else
               ons{8,sessno}=[ons{8,sessno} temp4(j)];
               trial_payoff_pf_gain_bond_bad = [trial_payoff_pf_gain_bond_bad temp5(j)]
               end;
          end;
      else
          if temp3(j)==1
               if temp9(j)== 4 || temp9(j)==6;
               ons{9,sessno}=[ons{9,sessno} temp4(j)];
               trial_payoff_pf_loss_stock_good = [trial_payoff_pf_loss_stock_good temp5(j)]
               else
               ons{10,sessno}=[ons{10,sessno} temp4(j)];
               trial_payoff_pf_loss_stock_bad = [trial_payoff_pf_loss_stock_bad temp5(j)]
               end;
          else
               if temp9(j)== 4 || temp9(j)==6;
               ons{11,sessno}=[ons{11,sessno} temp4(j)];
               trial_payoff_pf_loss_bond_good = [trial_payoff_pf_loss_bond_good temp5(j)]
               else
               ons{12,sessno}=[ons{12,sessno} temp4(j)];
               trial_payoff_pf_loss_bond_bad = [trial_payoff_pf_loss_bond_bad temp5(j)]
               end;
          end;
      end;
    end;
    
    ons{13,sessno} = [];
    ons{14,sessno} = [];
    
    for j=1:length(temp1)
      if temp1(j)== 1 || temp1(j)== 2;
          ons{13,sessno}=[ons{13,sessno} temp6(j)];
      else
          ons{14,sessno}=[ons{14,sessno} temp6(j)];
      end;
    end;
    
    ons{15,sessno} = [];
    ons{16,sessno} = [];
        
    for j=1:length(temp1)
      if temp1(j)== 1 || temp1(j)== 2;
          ons{15,sessno}=[ons{15,sessno} temp7(j)];
      else
          ons{16,sessno}=[ons{16,sessno} temp7(j)];
      end;
    end;
    
    % define durations
    %--------------------
    % ons_duration{j,i} with ons_name j and session i
    
    ons_duration{1,sessno}=[]; 
    ons_duration{2,sessno}=[];
    ons_duration{3,sessno}=[];
    ons_duration{4,sessno}=[]; 
    
    for j=1:length(temp1)
      if temp1(j)== 1 || temp1(j)== 2;
          if temp3(j)==1
          ons_duration{1,sessno}=[ons_duration{1,sessno} temp8(j)];
          else
          ons_duration{2,sessno}=[ons_duration{2,sessno} temp8(j)];
          end;
      else
          if temp3(j)==1
          ons_duration{3,sessno}=[ons_duration{3,sessno} temp8(j)];
          else
          ons_duration{4,sessno}=[ons_duration{4,sessno} temp8(j)];
          end;
      end;
    end;
    
    ons_duration{5,sessno}=0;
    ons_duration{6,sessno}=0;
    ons_duration{7,sessno}=0; 
    ons_duration{8,sessno}=0;
    ons_duration{9,sessno}=0;
    ons_duration{10,sessno}=0;
    ons_duration{11,sessno}=0;
    ons_duration{12,sessno}=0;
    ons_duration{13,sessno}=0;
    ons_duration{14,sessno}=0;
    ons_duration{15,sessno}=0;
    ons_duration{16,sessno}=0;
     
%========================================================================     
% DEFINE MODULATING PARAMETERS
%------------------------------------------------------------------------
% ons_modulate{i,j}{k} with session i, variables (cp. ons_name) j, modulations k
    
    for j=1:length(ons_name) 
        
         % 
         ons_modulate{sessno,5}{1}.name='trial_payoff'; 
         ons_modulate{sessno,5}{1}.P=eval('trial_payoff_pf_gain_stock_good')'; 
         ons_modulate{sessno,5}{1}.h=1;
         
         % 
         ons_modulate{sessno,6}{1}.name='trial_payoff'; 
         ons_modulate{sessno,6}{1}.P=eval('trial_payoff_pf_gain_stock_bad')'; 
         ons_modulate{sessno,6}{1}.h=1;
         
         % 
         ons_modulate{sessno,7}{1}.name='trial_payoff'; 
         ons_modulate{sessno,7}{1}.P=eval('trial_payoff_pf_gain_bond_good')'; 
         ons_modulate{sessno,7}{1}.h=1;
         
         % 
         ons_modulate{sessno,8}{1}.name='trial_payoff'; 
         ons_modulate{sessno,8}{1}.P=eval('trial_payoff_pf_gain_bond_bad')'; 
         ons_modulate{sessno,8}{1}.h=1;
         
         %
         ons_modulate{sessno,9}{1}.name='trial_payoff'; 
         ons_modulate{sessno,9}{1}.P=eval('trial_payoff_pf_loss_stock_good')'; 
         ons_modulate{sessno,9}{1}.h=1;
         
         % 
         ons_modulate{sessno,10}{1}.name='trial_payoff'; 
         ons_modulate{sessno,10}{1}.P=eval('trial_payoff_pf_loss_stock_bad')'; 
         ons_modulate{sessno,10}{1}.h=1;
         
         % 
         ons_modulate{sessno,11}{1}.name='trial_payoff'; 
         ons_modulate{sessno,11}{1}.P=eval('trial_payoff_pf_loss_bond_good')'; 
         ons_modulate{sessno,11}{1}.h=1;
         
         % 
         ons_modulate{sessno,12}{1}.name='trial_payoff'; 
         ons_modulate{sessno,12}{1}.P=eval('trial_payoff_pf_loss_bond_bad')'; 
         ons_modulate{sessno,12}{1}.h=1;
         
         % empty modulation for all variables (if needed)
         ons_modulate{sessno,j}{1}.name=''; 
         ons_modulate{sessno,j}{1}.P=[]; 
         ons_modulate{sessno,j}{1}.h=1;
        
    end % (j) (onsname)
         
    
        % load movement regressors
        %-------------------------
        % You want to check whether this fits the path to your movement 
        % regressors. Here, a text file "parameters.txt" is stored in your
        % participant folder
        
		clear mov_reg{sessno}; 
        
        cd ([subdir filesep 'realign']);
          path = dir('*.txt');
          mov_reg_ges=eval(['load(path.name)']); 
          mov_reg{sessno} = mov_reg_ges(1:length(mov_reg_ges),1:6);

        % cov_name [1 x c cell] array with names of c covariates
          cov_name{sessno}=[{'Mov_Reg1'} {'Mov_Reg2'} {'Mov_Reg3'} {'Mov_Reg4'} {'Mov_Reg5'} {'Mov_Reg6'}];   
        % cov [c x sessno] cell array with [nscans x c double] regressors 
          cov{sessno}= mov_reg{sessno};  

        % define location of functional images
		%-------------------------------------
        
		clear filestr{sessno}; 
        
		filestr{sessno}=[subdir filesep SubjectSession{sessno}]; 
	
	end	% (sessno)
	
	
        % make model directory & move there 
        %-------------------------------------
        try  cd (outputdir)
        catch mkdir ([outputdir])
              cd (outputdir)
        end
   
	% make design matrix
    %-------------------------------------
    % this function needs to be in matlab path 
    % (cp. ADDPATH command above)
    
    SPM = makeSPMdesignmatrix_mov_reg(filestr,ons,ons_name,ons_duration,ons_modulate,cov,cov_name);
	
    % Save spm version for future reference
    %-------------------------
    [v,r] = spm('Ver','',1);
    SPM.version=([v '_r' r]);
    	
	% evaluate design matrix
    %-----------------------
  	SPM = spm_spm(SPM);

end %~exist SPM
end % cononly

%========================================================================
% MAKE CONTRASTS
%------------------------------------------------------------------------
% check if contrast 1 already exist   
if ~exist([outputdir filesep 'con_0001.img'],'file')

    cd (outputdir)
    load SPM.mat

    c{1}=[1 -1 0 0  0 0 0 0  0 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{1}='choice_stock_gain_vs_bond_gain';	
    
    c{2}=[0 0 1 -1  0 0 0 0  0 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{2}='choice_stock_loss_vs_bond_loss'	;
    
    c{3}=[0 0 0 0  1 0 -1 0  0 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{3}='payoff_gain_stock_good_vs_bad'	;
    
    c{4}=[0 0 0 0  0 0 0 0  0 0 0 0  1 0 -1 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{4}='payoff_loss_stock_good_vs_bad'	;
    
    c{5}=[0 0 0 0  0 0 0 0  1 0 -1 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{5}='payoff_gain_bond_good_vs_bad'	;
    
    c{6}=[0 0 0 0  0 0 0 0  0 0 0 0  0 0 0 0  1 0 -1 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{6}='payoff_loss_bond_good_vs_bad'	;
    
    c{7}=[0 0 0 0  1 0 0 0  -1 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{7}='payoff_gain_good_stock_vs_bond'	;
    
    c{8}=[0 0 0 0  0 0 0 0  0 0 0 0  1 0 0 0  -1 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{8}='payoff_loss_good_stock_vs_bond'	;
    
    c{9}=[0 0 0 0  0 0 1 0  0 0 -1 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{9}='payoff_gain_bad_stock_vs_bond'	;
    
    c{10}=[0 0 0 0  0 0 0 0  0 0 0 0  0 0 1 0  0 0 -1 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{10}='payoff_loss_bad_stock_vs_bond'	;
    
    c{11}=[0 0 0 0  1 0 0 0  0 0 -1 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{11}='payoff_gain_good_stock_vs_bad_bond'	;
    
    c{12}=[0 0 0 0  0 0 0 0  0 0 0 0  1 0 0 0  0 0 -1 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{12}='payoff_loss_good_stock_vs_bad_bond'	;
    
    c{13}=[0 0 0 0  0 0 -1 0  1 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{13}='payoff_gain_good_bond_vs_bad_stock'	;
    
    c{14}=[0 0 0 0  0 0 0 0  0 0 0 0  0 0 -1 0  1 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    cname{14}='payoff_loss_good_bond_vs_bad_stock'	;
    
    %for additional contrasts
    %c{}=[0 0 0 0  0 0 0 0  0 0 0 0   0 0  0 0   0 0 0 0 0 0   0];
    %cname{}='' ;
    
    % make contrasts
    % -----------------
    for j=1:length(c)

        cons(j)   = spm_FcUtil('Set',cname{j},'T','c',c{j}(:),SPM.xX.xKXs);

    end;

    SPM.xCon = [cons];

    spm_contrasts(SPM);

    % save SPM for this subject
    % -----------------
    save SPM SPM;

end % if ~exist contrasts 

end  % this ends the main subject loop<