function SPM = makeSPMdesignmatrix_mov_reg(filestr,ons,ons_name,ons_duration,ons_modulate,cov,cov_name)

% Script provided by H�usler et al (2017)
% (anh@uni-bonn.de)
% Makedesignmatrix

%===========================================================================
% START SPM AND DEFINE SOME GLOBAL PARAMETERS
%------------------------------------------------------------------------

NumSessions = length(filestr);
NumVar=length(ons_name);				

global defaults;
    
%===========================================================================
% SPECIFY DESIGN VARIABLES
%===========================================================================


	%%%%%%%%%%%%%%%%%
	% TR
	%%%%%%%%%%%%%%%%%

    TR = 2.5;
    SPM.xY.RT          = TR;                              % seconds
    
    
    
	%%%%%%%%%%%%%%%%%
	% basis functions and timing parameters
	%%%%%%%%%%%%%%%%%    
    %---------------------------------------------------------------------------
    % OPTIONS for first field:
    %		  'hrf'
    %         'hrf (with time derivative)'
    %         'hrf (with time and dispersion derivatives)'
    %         'Fourier set'
    %         'Fourier set (Hanning)'
    %         'Gamma functions'
    %         'Finite Impulse Response'
    %---------------------------------------------------------------------------
    
    SPM.xBF.name       = 'hrf';
    SPM.xBF.length     = 32.2;              % length in seconds
    SPM.xBF.order      = 1;                 % order of basis set				
    SPM.xBF.T          = 16;                % number of time bins per scan
    SPM.xBF.T0         = 8;			    % first time bin (see slice timing)
    										% NOTE: the default in SPM in scan 1
    										% Pick SPM.xBF.T/2 (assuming exists negligible gap between slice acquisitions)
    										% to temporally realign the regressors so that they match responses in the middle slice 
    SPM.xBF.UNITS      = 'secs';            % OPTIONS: 'scans'|'secs' for onsets
    SPM.xBF.Volterra   = 1;		            % OPTIONS: 1|2 = order of convolution; 2 creates regressors by multiplying the original one
      
        
    
 	%%%%%%%%%%%%%%%%%
	% Trial specification: Onsets, duration and parameters for modulation
	%
	% NOTE:
	% - Units for durantion should be the same as in SPM.xBF.UNITS
	%
	%%%%%%%%%%%%%%%%%    
    
    for i=1:NumSessions
    
    	counter=1;
    	for j=1:NumVar
        	if ~isempty(ons{j,i})	        	
				
				%put in condition variables        	
            	SPM.Sess(i).U(counter).name = ons_name(j);
            	SPM.Sess(i).U(counter).ons = ons{j,i};
            	%SPM.Sess(i).U(counter).dur = ons_duration{j,i} * ones(length(ons{j,i}),1);  
            	SPM.Sess(i).U(counter).dur = ons_duration{j,i};  
            	% put in modulators
            	for k=1:length(ons_modulate{i,j})
                   	SPM.Sess(i).U(counter).P(k).name = ons_modulate{i,j}{k}.name;	%name of modulator
                	SPM.Sess(i).U(counter).P(k).P = ons_modulate{i,j}{k}.P;
                    SPM.Sess(i).U(counter).P(k).h= ons_modulate{i,j}{k}.h;
               	end
				
				counter=counter+1; %don't want to use j in case an onset is empty
				
            end
    	end
    
    end
    
    
 	%%%%%%%%%%%%%%%%%
	% specify data: matrix of filenames
	%%%%%%%%%%%%%%%%%    

	SPM.xY.P=[]
	
	for i=1:NumSessions
        files = {};
    	Directory 	=	filestr{i};
    	Filter 		= 	['*preproc*.nii']; % ge�ndert 15.4.2010
    	files		=	dir([Directory filesep Filter]);
    
    
    
    	for f=1:length(files)
    		SPM.xY.P	= cat(1,SPM.xY.P, [Directory filesep files(f).name]);
        end
         SPM.nscan(i) = length(files);
    
    end
    
    
    %%%%%%%%%%%%%%%%%
	% -- User Specified Covariates -- 
    % (e.g. movement parameters)
	%%%%%%%%%%%%%%%%%    
    for i=1:NumSessions
		SPM.Sess(i).C.C    = cov{i};	    % [n x c double ] regressors , (n Scans, c regressors)
		SPM.Sess(i).C.name = cov_name{i};   % [1 x c cell] names of regressors
	end 	% ge�ndert 15.4.2010 (Sarah)
    
    %%%%%%%%%%%%%%%%%
	% global normalization: OPTINS:'Scaling'|'None'
	% 
	% NOTE:
	% - If choose yes for Global Scaling then need to enter more fields
	%%%%%%%%%%%%%%%%%
  
    
    SPM.xGX.iGXcalc    = 'None';
    

	%%%%%%%%%%%%%%%%%
	% low frequency confound: high-pass cutoff (secs) [Inf = no filtering]
	%%%%%%%%%%%%%%%%%
    
    SPM.xX.K.HParam    = 128;
    
    
    %%%%%%%%%%%%%%%%%
	% intrinsic autocorrelations: OPTIONS: 'none'|'AR(1) + w'
	%%%%%%%%%%%%%%%%%
	
    SPM.xVi.form       = 'AR(1) + w';


        
%===========================================================================
% Configure design matrix
%===========================================================================

disp('configuring the design matrix ...');
SPM = spm_fmri_spm_ui(SPM);
disp('finished making the design matrix ...');
    
 