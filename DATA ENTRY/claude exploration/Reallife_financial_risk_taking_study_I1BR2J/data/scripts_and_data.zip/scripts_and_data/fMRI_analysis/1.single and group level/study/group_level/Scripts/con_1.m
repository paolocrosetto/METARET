% Script created by Sarah Rudorf and Alexander Niklas H�usler
%
% Group level script for group contrast analysis
%
% Script run in SPM12: v6470 in Matlab R2014a, on macOS Sierra 10.12.3
%
% Please note: all places where another researcher has to adjust the script
% are marked by "-->Adjust!!!"

clc;
clear all;
spm fmri 

% ====================================================================
% General Study Parameters
% --------------------------------------------------------------------

% --> SET your study parameters:
    % ______________________________________________________

    % SET study directory here -->Adjust!!!
    studypath = '/.../study/_data'; 

    % SET folder to con images
    studir= 'GLM';
    
    % ENTER subject ids here -->Adjust!!!
    subj_ids = {'1^2302017','2^2302017'}; 

    % SET con images over which you want to run the t-tests    
    confile = {'con_0001'};
    % SET names for contrasts (must be same length as confile)
    conname = {'con_0001_1'};
    

% ====================================================================
% Specify Design & Estimate
% --------------------------------------------------------------------

for conno=1:length(confile); % loop over con images
    
    % Create folder to save SPM.mat in & move there -->Adjust!!!
      outputdir=(['/.../study/group_level/Results/full_contrasts/1']);

      try  cd ([outputdir])
      catch mkdir ([outputdir])
            cd ([outputdir])
      end    

    %----------------------------------------------------------------------
    % Design specification
    %----------------------------------------------------------------------

    matlabbatch{1}.spm.stats.factorial_design.dir = {[outputdir]};
    matlabbatch{1}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.masking.tm.tm_none = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.em = {''};
    matlabbatch{1}.spm.stats.factorial_design.globalc.g_omit = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 1;

    % preallocate
    matlabbatch{1}.spm.stats.factorial_design.des(1).t1.scans= {''};

    % Read in scans for all subjects
    for subno=1:length(subj_ids);
    matlabbatch{1}.spm.stats.factorial_design.des.t1.scans(subno,1) = {[studypath '/' subj_ids{subno} '/' studir '/' confile{conno} '.nii,1']};
    end % subno

    %----------------------------------------------------------------------
    % Estimate
    %----------------------------------------------------------------------
    
    matlabbatch{2}.spm.stats.fmri_est.spmmat = {[outputdir '/SPM.mat']};
    matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;  

    % run nogui
    spm_jobman('run', matlabbatch)  
  
 
% ====================================================================
% MAKE CONTRASTS
% --------------------------------------------------------------------

    cd (outputdir);
    load SPM;

    % define contrasts
    % -----------------

    c{1}=[1];
    cname{1}=([conname{conno}]); 
    
    % make contrasts
    % -----------------
        for j=1:length(c)
            cons(j)   = spm_FcUtil('Set',cname{j},'T','c',c{j}(:),SPM.xX.xKXs);
        end;

        SPM.xCon = [cons];

        spm_contrasts(SPM);

    % save SPM for this analysis
    % --------------------------
        save SPM SPM;
    
end % conno

disp(['Done. ' datestr(now)])