*STATA 13.1 analysis script for the financial risk taking study by H�usler et al.
*Written by Alexander Niklas H�usler

*Dependent variable:
*active_stock_trading_yn: Question #21 in Questionnaire (Document S1): "Do you yourself trade stocks?"

*Independent variables:
*Extracted weighted beta values from the fMRI task:
*con_X_ai_r_p: Extracted brain data from the right anterior insula (mask by Smith et al. 2014) for contrast X
*con_X_ai_l_s: Extracted brain data from the left anterior insula (mask from Preuschoff et al. 2008) for contrast X
*con_X_vmpfc_b: Extracted brain data from the ventromedial prefrontal cortex (mask by Bartra et al. 2013) for contrast X
*con_X_nacc_bil_s: Extracted brain data from the bilateral nucleus accumbens/ventral striatum (mask by Smith et al. 2014) for contrast X
*con_X_ffa_r_f: Extracted brain data from the right fusiform face area (mask by Fusar-Poli et al. 2009) for contrast X

*Variables that are part of risk tolerance:
*self_risk_fin: Question #29b: Self-assessment of financial risk taking
*self_risk_tru: Question #29f: Self-assessment of risk taking when trusting strangers 
*risk_seek_hypo_lott: Question #39: Risk taking in the hypothetical lottery question
*fin_inv_exc: Question #30a: Liking the excitement of risks
*fin_inv_urge: Question #30d: Feeling that the urge to win outweighs the fear to lose
*fin_inv_psyc: Question #30e: Feeling psychologically pressured due to financial risks
*risk_seek_fmri_first: Stock/Bond ratio in fMRI paradigm, but only from the first trial in each block
*risk_seek_alloc: Average amount invested into stocks in behavioral stock allocation task

*Variables that are part of risk optimism:
*self_fin_kno: Question #32a: Self-assessment of financial knowledge
*self_math_kno: Question #32b: Self-assessment of mathematical abilities
*fin_inv_spec: Question #30f: Believing that speculation is a useful way to increase money
*fin_inv_kno: Question #30c: Trusting your own financial expertise
*fin_inv_prob: Question #30b: Thoroughly checking the theoretical probabilities before making financial investments to avoid mistakes
*risk_seek_optimism_fmri: Overestimation of goodness of stock in fMRI paradigm

*Variables that are part of household and cognitive characteristics:
*income_netto_hh: Question #14: Household income (after taxes) in the last year
*financial_liabilities_yn: Question #23: Having financial liabilities
*years_edu: Questions #5 & #6: Years of eduction (school and higher eduction combined)
*fin_lit: Questions #39 & #40 & #41: Financial literacy
*debt_lit: Questions #42 & #43: Debt literacy
*numeracy: Questions #45 & #46 & #47:  Numeracy
*iq_verbal: Verbal intelligence as assessed via analogies in the Intelligence-Structure-Test 2000R
*iq_numerical: Numerical intelligence as assessed via number rows in the Intelligence-Structure-Test 2000R
*iq_figural: Figural intelligence as assessed via matrices in the Intelligence-Structure-Test 2000R

*Additional variables:
*age: Question #1: Age
*risk_learn_error_fmri: stock estimation error in the fMRI task

*------------
*Pre-analysis
*------------
*It was first assessed, how many complete data sets were obtained (after all exclusions) and the variable "_est_participants_fmri_model" was created to make sure that only (n=157) those individuals were used for the analysis

*Association of active stock trading with other self-reported real-life variables and the self-assessment of financial risk taking
*fin_inv_yn: Question#19: Having financial investemnts (transformed into Yes/No)
*fin_inv_perc_stock_funds_yn: Question #19: Having a fraction of your financial investments invested into stocks and mutual funds (transformed into Yes/No)
tab active_stock_trading_yn fin_inv_yn, chi V
tab active_stock_trading_yn fin_inv_perc_stock_funds_yn, chi V
ttest self_risk_fin, by(active_stock_trading_yn)

*------------
*Main Figures
*------------
*Figure 3
*Legend is taken from this sample graph
twoway (kdensity age, lcolor(black)) (kdensity age if active_stock_trading_yn==1, lcolor(blue)) (kdensity age if active_stock_trading_yn==0, lcolor(red)), legend(label(1 "All participants") label(2 "Only stock traders") label(3 "Only non-stock traders")) legend(rows(3)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Age) graphregion(color(white)) name(age, replace)
*Variables included in the analysis
twoway (kdensity con_1_ai_l_p, lcolor(black)) (kdensity con_1_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_1_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Contrast values") yla(, notick nogrid nolabels) xla(, grid) title("Left AI activation{sup:1}") graphregion(color(white)) name(con_1_ai_l_p, replace)
twoway (kdensity con_1_ai_r_s, lcolor(black)) (kdensity con_1_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_1_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Contrast values") yla(, notick nogrid nolabels) xla(, grid) title("Right AI activation{sup:1}")  graphregion(color(white)) name(con_1_ai_r_s, replace)
twoway (histogram active_stock_trading_yn if _est_participants_fmri_model==1, percent lcolor(black) fcolor(none) discrete) , legend(off) graphregion(color(white)) ytitle("%", height(5)) xtitle("") xla(0 "No" 1 "Yes",) title(Active stock trading) graphregion(color(white)) name(active_stock_trading_yn, replace)
twoway (histogram income_netto_hh if active_stock_trading_yn==0 & _est_participants_fmri_model==1, start(1) lcolor(red) fcolor(red) width(1) discrete) (histogram income_netto_hh if active_stock_trading_yn==1 & _est_participants_fmri_model==1, start(1) lcolor(blue) fcolor(none) width(1) discrete) , legend(off) graphregion(color(white)) ytitle("") xtitle("Bins{sup:2}") yla(, notick nogrid nolabels) xla(1 2 3 4 5 6 7 8, grid) title(Household income (after taxes), size(medium)) graphregion(color(white)) name(income_netto_hh, replace) 
twoway (histogram financial_liabilities_yn if active_stock_trading_yn==0 & _est_participants_fmri_model==1, percent lcolor(red) fcolor(red) discrete) (histogram financial_liabilities_yn if active_stock_trading_yn==1 & _est_participants_fmri_model==1, percent lcolor(blue) fcolor(none)  discrete) , legend(off) graphregion(color(white)) ytitle("%", height(5)) xtitle("") xla(0 "No" 1 "Yes",) title(Having financial liabilities, size(medium)) graphregion(color(white)) name(financial_liabilities_yn, replace)
twoway (histogram years_edu if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red) fcolor(red) discrete) (histogram years_edu if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue) fcolor(none) discrete) , legend(off) graphregion(color(white)) ytitle("") xtitle("Years") yla(, notick nogrid nolabels) xla(, grid) title(Years of education) graphregion(color(white)) name(years_edu, replace) 
twoway (histogram fin_lit if active_stock_trading_yn==0, lcolor(red) fcolor(red) discrete) (histogram fin_lit if active_stock_trading_yn==1, lcolor(blue) fcolor(none) discrete) , legend(off) graphregion(color(white)) ytitle("") xtitle("Number of correct answers") yla(, notick nogrid nolabels) xla(0 1 2 3, grid) title(Financial literacy) graphregion(color(white)) name(fin_lit, replace) 
twoway (histogram debt_lit if active_stock_trading_yn==0, lcolor(red) fcolor(red) discrete) (histogram debt_lit if active_stock_trading_yn==1, lcolor(blue) fcolor(none) discrete) , legend(off) graphregion(color(white)) ytitle("") xtitle("Number of correct answers") yla(, notick nogrid nolabels) xla(0 1 2, grid) title(Debt literacy) graphregion(color(white)) name(debt_lit, replace) 
twoway (histogram numeracy if active_stock_trading_yn==0, lcolor(red) fcolor(red) discrete) (histogram numeracy if active_stock_trading_yn==1, lcolor(blue) fcolor(none) discrete) , legend(off) graphregion(color(white)) ytitle("") xtitle("Number of correct answers") yla(, notick nogrid nolabels) xla(0 1 2 3, grid) title(Numeracy) graphregion(color(white)) name(numeracy, replace) 
twoway (kdensity iq_verbal, lcolor(black)) (kdensity iq_verbal if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity iq_verbal if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Intelligence score") yla(, notick nogrid nolabels) xla(, grid) title(Verbal intelligence) graphregion(color(white)) name(iq_verbal, replace)
twoway (kdensity iq_numerical, lcolor(black)) (kdensity iq_numerical if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity iq_numerical if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Intelligence score") yla(, notick nogrid nolabels) xla(, grid) title(Numerical intelligence) graphregion(color(white)) name(iq_numerical, replace)
twoway (kdensity iq_figural, lcolor(black)) (kdensity iq_figural if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity iq_figural if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Intelligence score") yla(, notick nogrid nolabels) xla(, grid) title(Figural intelligence) graphregion(color(white)) name(iq_figural, replace)
twoway (kdensity ROI1, lcolor(black)) (kdensity ROI1 if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity ROI1 if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Principal component score") yla(, notick nogrid nolabels) xla(, grid) title(Risk optimism index) graphregion(color(white)) name(ROI1, replace)
twoway (kdensity RTI1, lcolor(black)) (kdensity RTI1 if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity RTI1 if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("Principal component score") yla(, notick nogrid nolabels) xla(, grid) title(Risk tolerance index) graphregion(color(white)) name(RTI1, replace) 
*Combining all the variables in the model end exporting that image
graph combine con_1_ai_l_p con_1_ai_r_s active_stock_trading_yn income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural ROI1 RTI1, graphregion(color(white))
graph export /.../Density_maps_sig.tif, width(4000)

*Mediation analysis (Supplementary Table 10) used for Figure 4
*l_AI_p_RTI_AST_analysis
version 13.1
set seed 10
sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RTI1) iv(con_1_ai_l_p)
bootstrap r(ind2tot) r(ind2dir) r(ind2dir) r(b_coef) r(a_coef) r(tot_eff) r(dir_eff) r(ind_eff), reps(10000) bca: sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RTI1) iv(con_1_ai_l_p)
estat bootstrap, percentile bca
*l_AI_p_ROI_AST_analysis
version 13.1
set seed 10
sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(ROI1) iv(con_1_ai_l_p)
bootstrap r(ind2tot) r(ind2dir) r(ind2dir) r(b_coef) r(a_coef) r(tot_eff) r(dir_eff) r(ind_eff), reps(10000) bca: sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(ROI1) iv(con_1_ai_l_p)
estat bootstrap, percentile bca
*r_AI_s_RTI_AST_analysis
version 13.1
set seed 10
sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RTI1) iv(con_1_ai_r_s)
bootstrap r(ind2tot) r(ind2dir) r(ind2dir) r(b_coef) r(a_coef) r(tot_eff) r(dir_eff) r(ind_eff), reps(10000) bca: sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RTI1) iv(con_1_ai_r_s)
estat bootstrap, percentile bca
*l_AI_p_RSPI_AST_analysis
version 13.1
set seed 10
sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RSPI) iv(con_1_ai_l_p)
bootstrap r(ind2tot) r(ind2dir) r(ind2dir) r(b_coef) r(a_coef) r(tot_eff) r(dir_eff) r(ind_eff), reps(10000) bca: sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RSPI) iv(con_1_ai_l_p)
estat bootstrap, percentile bca
*r_AI_s_RSPI_AST_analysis
version 13.1
set seed 10
sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RSPI) iv(con_1_ai_r_s)
bootstrap r(ind2tot) r(ind2dir) r(ind2dir) r(b_coef) r(a_coef) r(tot_eff) r(dir_eff) r(ind_eff), reps(10000) bca: sgmediation active_stock_trading_yn if _est_participants_fmri_model==1, mv(RSPI) iv(con_1_ai_r_s)
estat bootstrap, percentile bca

*-----------
*Main Tables
*-----------
*Table 1
sum active_stock_trading_yn if _est_participants_fmri_model==1, d
sum income_netto_hh if _est_participants_fmri_model==1, d
sum financial_liabilities_yn if _est_participants_fmri_model==1, d
sum years_edu if _est_participants_fmri_model==1, d
sum fin_lit if _est_participants_fmri_model==1, d
sum debt_lit if _est_participants_fmri_model==1, d
sum numeracy if _est_participants_fmri_model==1, d
sum iq_verbal if _est_participants_fmri_model==1, d
sum iq_numerical if _est_participants_fmri_model==1, d
sum iq_figural if _est_participants_fmri_model==1, d
sum ROI1 if _est_participants_fmri_model==1, d
sum RTI1 if _est_participants_fmri_model==1, d

*Table 2
reg active_stock_trading_yn con_1_ai_l_p if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural ROI1 if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural ROI1 RTI1 if _est_participants_fmri_model==1

*Table 3
reg active_stock_trading_yn con_1_ai_r_s if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural ROI1 if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural ROI1 RTI1 if _est_participants_fmri_model==1

*Table 4
reg con_1_ai_l_p RTI1 if _est_participants_fmri_model==1
reg con_1_ai_l_p ROI1 if _est_participants_fmri_model==1
reg con_1_ai_l_p RTI1 ROI1 if _est_participants_fmri_model==1
reg con_1_ai_r_s RTI1 if _est_participants_fmri_model==1
reg con_1_ai_r_s ROI1 if _est_participants_fmri_model==1
reg con_1_ai_r_s RTI1 ROI1 if _est_participants_fmri_model==1

*---------------------
*Supplementary Figures
*---------------------
*Supplementary Figure 1
twoway (kdensity con_1_vmpfc_b, lcolor(black)) (kdensity con_1_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_1_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 1{sup:*}, size(medium)) graphregion(color(white)) name(con_1_vmpfc_b, replace)
twoway (kdensity con_1_nacc_bil_s, lcolor(black)) (kdensity con_1_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_1_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 1{sup:*}, size(medium)) graphregion(color(white)) name(con_1_nacc_bil_s, replace)
twoway (kdensity con_1_ffa_r_f, lcolor(black)) (kdensity con_1_ffa_r_f if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_1_ffa_r_f if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right FFA activation during contrast 1{sup:*}, size(medium)) graphregion(color(white)) name(con_1_ffa_r_f, replace)

twoway (kdensity con_2_ai_l_p, lcolor(black)) (kdensity con_2_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_2_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 2{sup:*}, size(medium)) graphregion(color(white)) name(con_2_ai_l_p, replace)
twoway (kdensity con_2_ai_r_s, lcolor(black)) (kdensity con_2_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_2_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 2{sup:*}, size(medium)) graphregion(color(white)) name(con_2_ai_r_s, replace)
twoway (kdensity con_2_vmpfc_b, lcolor(black)) (kdensity con_2_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_2_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 2{sup:*}, size(medium)) graphregion(color(white)) name(con_2_vmpfc_b, replace)
twoway (kdensity con_2_nacc_bil_s, lcolor(black)) (kdensity con_2_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_2_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 2{sup:*}, size(medium)) graphregion(color(white)) name(con_2_nacc_bil_s, replace)

twoway (kdensity con_3_ai_l_p, lcolor(black)) (kdensity con_3_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_3_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 3{sup:*}, size(medium)) graphregion(color(white)) name(con_3_ai_l_p, replace)
twoway (kdensity con_3_ai_r_s, lcolor(black)) (kdensity con_3_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_3_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 3{sup:*}, size(medium)) name(con_3_ai_r_s, replace)
twoway (kdensity con_3_vmpfc_b, lcolor(black)) (kdensity con_3_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_3_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 3{sup:*}, size(medium)) graphregion(color(white)) name(con_3_vmpfc_b, replace)
twoway (kdensity con_3_nacc_bil_s, lcolor(black)) (kdensity con_3_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_3_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 3{sup:*}, size(medium)) graphregion(color(white)) name(con_3_nacc_bil_s, replace)

twoway (kdensity con_4_ai_l_p, lcolor(black)) (kdensity con_4_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_4_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 4{sup:*}, size(medium)) graphregion(color(white)) name(con_4_ai_l_p, replace)
twoway (kdensity con_4_ai_r_s, lcolor(black)) (kdensity con_4_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_4_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 4{sup:*}, size(medium)) graphregion(color(white)) name(con_4_ai_r_s, replace)
twoway (kdensity con_4_vmpfc_b, lcolor(black)) (kdensity con_4_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_4_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 4{sup:*}, size(medium)) graphregion(color(white)) name(con_4_vmpfc_b, replace)
twoway (kdensity con_4_nacc_bil_s, lcolor(black)) (kdensity con_4_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_4_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 4{sup:*}, size(medium)) graphregion(color(white)) name(con_4_nacc_bil_s, replace)

twoway (kdensity con_5_ai_l_p, lcolor(black)) (kdensity con_5_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_5_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 5{sup:*}, size(medium)) graphregion(color(white)) name(con_5_ai_l_p, replace)
twoway (kdensity con_5_ai_r_s, lcolor(black)) (kdensity con_5_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_5_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 5{sup:*}, size(medium)) graphregion(color(white)) name(con_5_ai_r_s, replace)
twoway (kdensity con_5_vmpfc_b, lcolor(black)) (kdensity con_5_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_5_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 5{sup:*}, size(medium)) graphregion(color(white)) name(con_5_vmpfc_b, replace)
twoway (kdensity con_5_nacc_bil_s, lcolor(black)) (kdensity con_5_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_5_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 5{sup:*}, size(medium)) graphregion(color(white)) name(con_5_nacc_bil_s, replace)

twoway (kdensity con_6_ai_l_p, lcolor(black)) (kdensity con_6_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_6_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 6{sup:*}, size(medium)) graphregion(color(white)) name(con_6_ai_l_p, replace)
twoway (kdensity con_6_ai_r_s, lcolor(black)) (kdensity con_6_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_6_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 6{sup:*}, size(medium)) graphregion(color(white)) name(con_6_ai_r_s, replace)
twoway (kdensity con_6_vmpfc_b, lcolor(black)) (kdensity con_6_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_6_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 6{sup:*}, size(medium)) graphregion(color(white)) name(con_6_vmpfc_b, replace)
twoway (kdensity con_6_nacc_bil_s, lcolor(black)) (kdensity con_6_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_6_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 6{sup:*}, size(medium)) graphregion(color(white)) name(con_6_nacc_bil_s, replace)

twoway (kdensity con_7_ai_l_p, lcolor(black)) (kdensity con_7_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_7_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 7{sup:*}, size(medium)) graphregion(color(white)) name(con_7_ai_l_p, replace)
twoway (kdensity con_7_ai_r_s, lcolor(black)) (kdensity con_7_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_7_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 7{sup:*}, size(medium)) graphregion(color(white)) name(con_7_ai_r_s, replace)
twoway (kdensity con_7_vmpfc_b, lcolor(black)) (kdensity con_7_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_7_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 7{sup:*}, size(medium)) graphregion(color(white)) name(con_7_vmpfc_b, replace)
twoway (kdensity con_7_nacc_bil_s, lcolor(black)) (kdensity con_7_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_7_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 7{sup:*}, size(medium)) graphregion(color(white)) name(con_7_nacc_bil_s, replace)

twoway (kdensity con_8_ai_l_p, lcolor(black)) (kdensity con_8_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_8_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 8{sup:*}, size(medium)) graphregion(color(white)) name(con_8_ai_l_p, replace)
twoway (kdensity con_8_ai_r_s, lcolor(black)) (kdensity con_8_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_8_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 8{sup:*}, size(medium)) graphregion(color(white)) name(con_8_ai_r_s, replace)
twoway (kdensity con_8_vmpfc_b, lcolor(black)) (kdensity con_8_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_8_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 8{sup:*}, size(medium)) graphregion(color(white)) name(con_8_vmpfc_b, replace)
twoway (kdensity con_8_nacc_bil_s, lcolor(black)) (kdensity con_8_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_8_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 8{sup:*}, size(medium)) graphregion(color(white)) name(con_8_nacc_bil_s, replace)
                      
twoway (kdensity con_9_ai_l_p, lcolor(black)) (kdensity con_9_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_9_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 9{sup:*}, size(medium)) graphregion(color(white)) name(con_9_ai_l_p, replace)
twoway (kdensity con_9_ai_r_s, lcolor(black)) (kdensity con_9_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_9_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 9{sup:*}, size(medium)) graphregion(color(white)) name(con_9_ai_r_s, replace)
twoway (kdensity con_9_vmpfc_b, lcolor(black)) (kdensity con_9_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_9_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 9{sup:*}, size(medium)) graphregion(color(white)) name(con_9_vmpfc_b, replace)
twoway (kdensity con_9_nacc_bil_s, lcolor(black)) (kdensity con_9_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_9_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 9{sup:*}, size(medium)) graphregion(color(white)) name(con_9_nacc_bil_s, replace)

twoway (kdensity con_10_ai_l_p, lcolor(black)) (kdensity con_10_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_10_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 10{sup:*}, size(medium)) graphregion(color(white)) name(con_10_ai_l_p, replace)
twoway (kdensity con_10_ai_r_s, lcolor(black)) (kdensity con_10_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_10_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 10{sup:*}, size(medium)) graphregion(color(white)) name(con_10_ai_r_s, replace)
twoway (kdensity con_10_vmpfc_b, lcolor(black)) (kdensity con_10_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_10_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 10{sup:*}, size(medium)) graphregion(color(white)) name(con_10_vmpfc_b, replace)
twoway (kdensity con_10_nacc_bil_s, lcolor(black)) (kdensity con_10_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_10_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 10{sup:*}, size(medium)) graphregion(color(white)) name(con_10_nacc_bil_s, replace)

twoway (kdensity con_11_ai_l_p, lcolor(black)) (kdensity con_11_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_11_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 11{sup:*}, size(medium)) graphregion(color(white)) name(con_11_ai_l_p, replace)
twoway (kdensity con_11_ai_r_s, lcolor(black)) (kdensity con_11_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_11_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 11{sup:*}, size(medium)) graphregion(color(white)) name(con_11_ai_r_s, replace)
twoway (kdensity con_11_vmpfc_b, lcolor(black)) (kdensity con_11_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_11_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 11{sup:*}, size(medium)) graphregion(color(white)) name(con_11_vmpfc_b, replace)
twoway (kdensity con_11_nacc_bil_s, lcolor(black)) (kdensity con_11_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_11_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 11{sup:*}, size(medium)) graphregion(color(white)) name(con_11_nacc_bil_s, replace)

twoway (kdensity con_12_ai_l_p, lcolor(black)) (kdensity con_12_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_12_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 12{sup:*}, size(medium)) graphregion(color(white)) name(con_12_ai_l_p, replace)
twoway (kdensity con_12_ai_r_s, lcolor(black)) (kdensity con_12_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_12_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 12{sup:*}, size(medium)) graphregion(color(white)) name(con_12_ai_r_s, replace)
twoway (kdensity con_12_vmpfc_b, lcolor(black)) (kdensity con_12_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_12_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 12{sup:*}, size(medium)) graphregion(color(white)) name(con_12_vmpfc_b, replace)
twoway (kdensity con_12_nacc_bil_s, lcolor(black)) (kdensity con_12_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_12_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 12{sup:*}, size(medium)) graphregion(color(white)) name(con_12_nacc_bil_s, replace)

twoway (kdensity con_13_ai_l_p, lcolor(black)) (kdensity con_13_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_13_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 13{sup:*}, size(medium)) graphregion(color(white)) name(con_13_ai_l_p, replace)
twoway (kdensity con_13_ai_r_s, lcolor(black)) (kdensity con_13_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_13_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 13{sup:*}, size(medium)) graphregion(color(white)) name(con_13_ai_r_s, replace)
twoway (kdensity con_13_vmpfc_b, lcolor(black)) (kdensity con_13_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_13_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 13{sup:*}, size(medium)) graphregion(color(white)) name(con_13_vmpfc_b, replace)
twoway (kdensity con_13_nacc_bil_s, lcolor(black)) (kdensity con_13_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_13_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 13{sup:*}, size(medium)) graphregion(color(white)) name(con_13_nacc_bil_s, replace)

twoway (kdensity con_14_ai_l_p, lcolor(black)) (kdensity con_14_ai_l_p if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_14_ai_l_p if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Left AI activation during contrast 14{sup:*}, size(medium)) graphregion(color(white)) name(con_14_ai_l_p, replace)
twoway (kdensity con_14_ai_r_s, lcolor(black)) (kdensity con_14_ai_r_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_14_ai_r_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Right AI activation during contrast 14{sup:*}, size(medium)) graphregion(color(white)) name(con_14_ai_r_s, replace)
twoway (kdensity con_14_vmpfc_b, lcolor(black)) (kdensity con_14_vmpfc_b if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_14_vmpfc_b if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(vmPFC activation during contrast 14{sup:*}, size(medium)) graphregion(color(white)) name(con_14_vmpfc_b, replace)
twoway (kdensity con_14_nacc_bil_s, lcolor(black)) (kdensity con_14_nacc_bil_s if active_stock_trading_yn==1 & _est_participants_fmri_model==1, lcolor(blue)) (kdensity con_14_nacc_bil_s if active_stock_trading_yn==0 & _est_participants_fmri_model==1, lcolor(red)), legend(off) graphregion(color(white)) ytitle("") xtitle("") yla(, notick nogrid nolabels) xla(, grid) title(Bil. VS activation during contrast 14{sup:*}, size(medium)) graphregion(color(white)) name(con_14_nacc_bil_s, replace)
*Combining all the remaining fmri variables from the model and exporting them
graph combine con_1_vmpfc_b con_1_nacc_bil_s con_1_ffa_r_f con_2_ai_l_p con_2_ai_r_s con_2_vmpfc_b con_2_nacc_bil_s con_3_ai_l_p con_3_ai_r_s con_3_vmpfc_b con_3_nacc_bil_s con_4_ai_l_p con_4_ai_r_s con_4_vmpfc_b con_4_nacc_bil_s con_5_ai_l_p con_5_ai_r_s con_5_vmpfc_b con_5_nacc_bil_s con_6_ai_l_p con_6_ai_r_s con_6_vmpfc_b con_6_nacc_bil_s con_7_ai_l_p con_7_ai_r_s con_7_vmpfc_b con_7_nacc_bil_s con_8_ai_l_p con_8_ai_r_s con_8_vmpfc_b con_8_nacc_bil_s con_9_ai_l_p con_9_ai_r_s con_9_vmpfc_b con_9_nacc_bil_s con_10_ai_l_p con_10_ai_r_s con_10_vmpfc_b con_10_nacc_bil_s con_11_ai_l_p con_11_ai_r_s con_11_vmpfc_b con_11_nacc_bil_s con_12_ai_l_p con_12_ai_r_s con_12_vmpfc_b con_12_nacc_bil_s con_13_ai_l_p con_13_ai_r_s con_13_vmpfc_b con_13_nacc_bil_s con_14_ai_l_p con_14_ai_r_s con_14_vmpfc_b con_14_nacc_bil_s, graphregion(color(white))
graph export /.../Density_maps_fmri_non_sig.tif, width(4000)

*Supplementary Figure 2
pwcorr RTI1 ROI1, sig obs
graph twoway (lfitci RTI1 ROI1) (scatter RTI1 ROI1)

*--------------------
*Supplementary Tables
*--------------------
*Supplementary Table 4
ttest con_1_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_1_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_1_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_1_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_1_ffa_r_f if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_2_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_2_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_2_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_2_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_3_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_3_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_3_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_3_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_4_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_4_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_4_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_4_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_5_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_5_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_5_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_5_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_6_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_6_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_6_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_6_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_7_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_7_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_7_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_7_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_8_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_8_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_8_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_8_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_9_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_9_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_9_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_9_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_10_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_10_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_10_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_10_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_11_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_11_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_11_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_11_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_12_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_12_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_12_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_12_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_13_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_13_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_13_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_13_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

ttest con_14_ai_l_p if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_14_ai_r_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_14_vmpfc_b if _est_participants_fmri_model==1, by(active_stock_trading_yn)
ttest con_14_nacc_bil_s if _est_participants_fmri_model==1, by(active_stock_trading_yn)

*Supplementary Table 5
*ROI
sum self_fin_kno, d
sum self_math_kno, d
sum fin_inv_spec, d
sum fin_inv_kno, d
sum fin_inv_prob, d
sum risk_seek_optimism_fmri, d
sum ROI1, d
*RTI
sum self_risk_fin, d
sum self_risk_tru, d
sum risk_seek_hypo_lott, d
sum fin_inv_exc, d
sum fin_inv_urge, d
sum fin_inv_psyc, d
sum risk_seek_fmri_first, d
sum risk_seek_alloc, d
sum RTI1, d

*Supplementary Tables 6 and 8
logistic active_stock_trading_yn self_fin_kno
logistic active_stock_trading_yn self_math_kno
logistic active_stock_trading_yn fin_inv_spec
logistic active_stock_trading_yn fin_inv_kno
logistic active_stock_trading_yn fin_inv_prob
logistic active_stock_trading_yn risk_seek_optimism_fmri
*Principal Component Analysis (PCA) to get risk optimism index with only the significant variables
pca self_fin_kno fin_inv_spec fin_inv_kno fin_inv_prob
screeplot, yline(1) ci(het)
predict pc1, score
rename pc1 ROI1
logistic active_stock_trading_yn ROI1

*Supplementary Tables 7 and 9
logistic active_stock_trading_yn self_risk_fin
logistic active_stock_trading_yn self_risk_tru
logistic active_stock_trading_yn risk_seek_hypo_lott
logistic active_stock_trading_yn fin_inv_exc
logistic active_stock_trading_yn fin_inv_urge
logistic active_stock_trading_yn fin_inv_psyc
logistic active_stock_trading_yn risk_seek_fmri_first
logistic active_stock_trading_yn risk_seek_alloc
*Principal Component Analysis (PCA) to get risk tolerance index with only the significant variables
pca self_risk_fin self_risk_tru risk_seek_hypo_lott fin_inv_exc fin_inv_urge fin_inv_psyc risk_seek_fmri_first
screeplot, yline(1) ci(het)
predict pc1, score
rename pc1 RTI1
logistic active_stock_trading_yn RTI1

*Supplementary Table 11
pwcorr iq_figural iq_numerical iq_verbal risk_learn_error_fmri, sig obs

*Supplemetary Table 12
pca self_risk_fin self_risk_tru risk_seek_hypo_lott fin_inv_exc fin_inv_urge fin_inv_psyc risk_seek_fmri_first self_fin_kno fin_inv_spec fin_inv_kno fin_inv_prob
screeplot, yline(1) ci(het)
predict pc1, score
rename pc1 RSPI
logistic active_stock_trading_yn RSPI
logistic active_stock_trading_yn RSPI income_netto_hh years_edu financial_liabilities_yn iq_figural

*Supplementary Table 13
reg active_stock_trading_yn con_1_ai_l_p if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_l_p income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural RSPI if _est_participants_fmri_model==1

*Supplementary Table 14
reg active_stock_trading_yn con_1_ai_r_s if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural if _est_participants_fmri_model==1
reg active_stock_trading_yn con_1_ai_r_s income_netto_hh financial_liabilities_yn years_edu fin_lit debt_lit numeracy iq_verbal iq_numerical iq_figural RSPI if _est_participants_fmri_model==1
