
use riskrplogs

*****************************************************
*correlation
****************************************************

pcorr tolerance fin_literacy female age urban lincome decisions fin_status family_members risk risk_perception
pcorr risk_perception fin_literacy female age urban lincome decisions fin_status family_members risk tolerance
pcorr risk fin_literacy female age urban lincome decisions fin_status family_members risk_perception tolerance



****************************************************************
*histogram
***************************************************************

 histogram risk, discrete width(1) percent xtitle(safe choices) title(revealed risk preference)
 
// histogram risk if game==5, discrete width(1) percent xtitle(safe choices) title(revealed risk preference task 1)
 //histogram risk if game==6, discrete width(1) percent xtitle(safe choices) title(revealed risk preference task 2)
// histogram risk if game==7, discrete width(1) percent xtitle(safe choices) title(revealed risk preference task 3)
 //histogram risk if game==8, discrete width(1) percent xtitle(safe choices) title(revealed risk preference task 4)
 
 histogram risk_perception, discrete width(1) percent xtitle(perceived risk) title(perceived financial risk)
 
 tab risk risk_perception, row col 
 
 tab risk risk_perception if gender==1, row col

 tab risk risk_perception if gender==2, row col
 
 tab risk risk_perception if fin_literacy>12, row col
 
 tab risk risk_perception if fin_literacy<=12, row col
 
 
 ****************************************************************
* revealed risk 
****************************************************************
xtset game

  xtreg lrisk c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members , re vce (robust)
 eststo a1, title(All)
  
 xtreg lrisk c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==1 , re vce (robust)
 eststo a2, title(male)
 
  xtreg lrisk c.lfin_literacy  c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==2  , re vce (robust)
 eststo a3, title(female)
 
 xtreg lrisk c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy>12 ,re vce (robust)
 eststo a4, title(high fin lit)
 
  xtreg lrisk c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy<=12  , re vce (robust)
 eststo a5, title(low fin lit)
 
 esttab a1 a2 a3 a4 a5  using fin_status1.rtf, r2 star(* 0.10 ** 0.05 *** 0.01) se(3) b(a2) compress ///*The compress option reduces horizontal spacing to fit more models on screen without line breaking*/
title( OLS Panel Regression : determinants of revealed risk ) /// 
nonumbers mtitles replace	


****************************************************************
* perceived risk 
****************************************************************
xtset game

  xtreg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members , vce (robust)
 eststo a1, title(OLS)
  
 xtreg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==1 , vce (robust)
 eststo a2, title(male)
 
  xtreg lrisk_perception c.lfin_literacy  c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==2  , re vce (robust)
 eststo a3, title(female)
 
 xtreg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy>12 , vce (robust)
 eststo a4, title(high fin lit)
 
  xtreg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy<=12  , re vce (robust)
 eststo a5, title(low fin lit)
 
 esttab a1 a2 a3 a4 a5  using fin_status2.rtf, r2 star(* 0.10 ** 0.05 *** 0.01) se(3) b(a2) compress ///*The compress option reduces horizontal spacing to fit more models on screen without line breaking*/
title(OLS Panel Regression : determinants of perceived risk ) /// 
nonumbers mtitles replace	

****************************************************************
*risk tolerance
****************************************************************
xtset game

  xtreg tolerance c.fin_literacy i.female c.age i.urban c.lincome i.decisions c.family_members ,re vce (robust)
 eststo a1, title(All)
  
 xtreg tolerance c.fin_literacy i.female c.age i.urban c.lincome i.decisions c.family_members if gender==1 , re vce (robust)
 eststo a2, title(male)
 
  xtreg tolerance c.fin_literacy  c.age i.urban c.lincome i.decisions c.family_members if gender==2  , re vce (robust)
 eststo a3, title(female)
 
 xtreg tolerance c.fin_literacy i.female c.age i.urban c.lincome i.decisions c.family_members if fin_literacy>12 ,re  vce (robust)
 eststo a4, title(high fin lit)
 
  xtreg tolerance c.fin_literacy i.female c.age i.urban c.lincome i.decisions c.family_members if fin_literacy<=12  , re vce (robust)
 eststo a5, title(low fin lit)
 
 esttab a1 a2 a3 a4 a5  using fin_status3.rtf, r2 star(* 0.10 ** 0.05 *** 0.01) se(3) b(a2) compress ///*The compress option reduces horizontal spacing to fit more models on screen without line breaking*/
title( OLS Panel Regression : determinants of risk tolerance ) /// 
nonumbers mtitles replace	

 
****************************************************************
*risk tolerance in log
****************************************************************
xtset game

  xtreg ltolerance c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members ,re vce (robust)
 eststo a1, title(All)
  
 xtreg ltolerance c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==1 , re vce (robust)
 eststo a2, title(male)
 
  xtreg ltolerance c.lfin_literacy  c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==2  , re vce (robust)
 eststo a3, title(female)
 
 xtreg ltolerance c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy>12 ,re  vce (robust)
 eststo a4, title(high fin lit)
 
  xtreg ltolerance c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy<=12  , re vce (robust)
 eststo a5, title(low fin lit)
 
 esttab a1 a2 a3 a4 a5  using fin_status3.rtf, r2 star(* 0.10 ** 0.05 *** 0.01) se(3) b(a2) compress ///*The compress option reduces horizontal spacing to fit more models on screen without line breaking*/
title( OLS Panel Regression : determinants of risk tolerance ) /// 
nonumbers mtitles replace	


****************************************************************
* perceived risk 
****************************************************************
use riskp

  reg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members , vce (robust)
 eststo a1, title(All)
  
 reg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==1 , vce (robust)
 eststo a2, title(male)
 
  reg lrisk_perception c.lfin_literacy  c.lage i.urban c.lincome i.decisions c.lfamily_members if gender==2  , vce (robust)
 eststo a3, title(female)
 
 reg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy>12 , vce (robust)
 eststo a4, title(high fin lit)
 
  reg lrisk_perception c.lfin_literacy i.female c.lage i.urban c.lincome i.decisions c.lfamily_members if fin_literacy<=12  , vce (robust)
 eststo a5, title(low fin lit)
 
 esttab a1 a2 a3 a4 a5  using fin_status_P_ols.rtf, r2 star(* 0.10 ** 0.05 *** 0.01) se(3) b(a2) compress ///*The compress option reduces horizontal spacing to fit more models on screen without line breaking*/
title( OLS Regression : determinants of perceived risk ) /// 
nonumbers mtitles replace	

 
 

