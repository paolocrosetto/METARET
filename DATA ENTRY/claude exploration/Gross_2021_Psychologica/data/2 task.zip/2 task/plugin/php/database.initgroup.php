<?php






try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subjects'])) {
		$subjects = $_POST['subjects'];
	}
	else {
		throw new exception("subjects not set");
	}
	
	if(isset($_POST['team_assignment'])) {
		$groups = $_POST['team_assignment'];
	}
	else {
		$groups = '';
	}


	// main routine
	
	$db_round = $name . "_round";
	$db_payment = $name . "_payment";
	
	$grouping = false;
	if(count($groups) == $subjects) {	 $grouping = true;	} 
	else {	$response["warning"][] = "no teams specified or wrongly specified - all subjects therefore are set to team 1";  }
	
	
	// add data
	
	for($subject = 1; $subject <= $subjects; $subject++) {
		
		if($grouping == false) {	$cur_team = 1;	}
		else {	$cur_team = $groups[$subject-1];  }
		
		$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
		$rows = $query -> fetchColumn();
		$query -> closeCursor(); 
						
		if($rows == 0) {
			
			$query = $db -> prepare("INSERT INTO $db_round VALUES (:group, :subject, :stage, :round, :team, 1)");
			$query -> execute(array(':group' => $group, ':subject' => $subject, ':stage' => 1, ':round' => 1, ':team' => $cur_team));
			$query -> closeCursor(); 
			
		}	
		else {	$response["warning"][] = "data from subject " . $subject . " (group " . $group . ") already in database (wrong group number?)";	}
	}	
	
	
	// response
	
	$response["result"] = "success";
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
	

?>


