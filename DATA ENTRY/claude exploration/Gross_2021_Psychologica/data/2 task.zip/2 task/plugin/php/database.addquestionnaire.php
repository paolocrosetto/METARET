<?php

try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['questions'])) {
		$questions = $_POST['questions'];
	}
	else {
		throw new exception("questions not set");
	}
	
	// get optional variables
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
		if(count($comment) != count($questions)) {	$comment = array_fill(0,count($questions),''); $response["warning"][] = "number of comments do not match number of entries to add - comments are ignored";	}		
	}
	else {
		$comment = array_fill(0,count($questions),'');
		$response["warning"][] = "comment not set";
	}
	
	
	// main routine
	
	$date = getdate();
	$date = $date['year'] . "_". $date['mon'] . "_".  $date['mday'] . "_". $date['hours'] . "_". $date['minutes'] . "_". $date['seconds'];
	
	$db_questionnaire = $name . "_questionnaire";
	$db_round = $name . "_round";
	
	
	// get team
	
	$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject " . $subject . " not found in waiting table for group " . $group);	}
	else {	
		
		$query = $db -> prepare("SELECT team FROM $db_round WHERE `group` = :group AND subject = :subject");		
		$query -> execute(array(":subject" => $subject, ":group" => $group));

		$result = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$team = $result['team']; 
	}
		
	
	// add entries

	$i = 0;
	foreach($questions as $key => $value) {	
					
		$query = $db -> query("SELECT count(*) FROM $db_questionnaire WHERE `group` = $group AND subject = $subject AND label = '$key'");		
		$rows = $query -> fetchColumn();
		$query -> closeCursor(); 
		
		if($rows != 0) {	
			$response["warning"][] = "entry for $key already exists for group $group, subject $subject  - no data added";
			#throw new exception("entry already exists for group $group, subject $subject  - no data added");	
		}
		else {
						
			$assWhere = array(
				":date" => $date,
			    ":group"  => $group,
			    ":subject" => $subject,
				":team" => $team,
			    ":label" => $key,
				":value" => $value,
				":comment" => $comment[$i]
			);
				
			$query_string = "INSERT INTO $db_questionnaire VALUES (:date, :group, :subject, :team, :label, :value, :comment)";
				
			$query = $db -> prepare($query_string);
			$query -> execute($assWhere);
			$query -> closeCursor(); 
		}	

		$i = $i+1;
	}

		
	// response
	
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}

?>