<?php


try {
	
	include("database.php");
	$response = array();
	
	
	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		throw new exception("round not set");
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		throw new exception("stage not set");
	}

	if(isset($_POST['responses'])) {
		$responses = $_POST['responses'];
	}
	else {
		throw new exception("responses not set");
	}

	// get optional variables
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		$subject = "";
		$response["warning"][] = "subject not set";
	}
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}
	
	if(isset($_POST['condition'])) {
		$condition = $_POST['condition'];
	}
	else {
		$condition = "";
		$response["warning"][] = "condition not set";
	}
	
	if(isset($_POST['type'])) {
		$type = $_POST['type'];
	}
	else {
		$type = "";
		$response["warning"][] = "type not set";
	}
	
	if(isset($_POST['team'])) {
		$team = $_POST['team'];
	}
	else {
		$team = "";
		$response["warning"][] = "team not set";
	
	}
	
	
	// main routine
	
	$group  = (array) $group; $groupSQL = ":group" . implode(", :group", $group);
	$stage  = (array) $stage; $stageSQL = ":stage" . implode(", :stage", $stage);
	$round  = (array) $round; $roundSQL = ":round" . implode(", :round", $round);
	
	if($subject != "") {		$subject  = (array) $subject; $subjectSQL = ":subject" . implode(", :subject", $subject);	}
	if($condition != "") {		$condition = (array) $condition; $conditionSQL = ":condition" . implode(", :condition", $condition);	}	
	if($comment != "") {	$comment = (array) $comment; $commentSQL = ":comment" . implode(", :comment", $comment);	}
	if($type != "") {		$type = (array) $type; $typeSQL = ":type" . implode(", :type", $type);	}
	if($team != "") {	$team = (array) $team; $teamSQL = ":team" . implode(", :team", $team);	}
		
	$db_behavior = $name . "_behavior";


	// read procedure
	
	$arrWhere = array();
	$assWhere = array();
	
	if($type != "") {
	    $arrWhere[] = "type IN(" . $typeSQL . ")";
		foreach($type as $value) {
			$assWhere[":type" . $value] = $value;
		}			
	}
	if($condition != "") {
	    $arrWhere[] = "`condition` IN(" . $conditionSQL . ")";
		foreach($condition as $value) {
			$assWhere[":condition" . $value] = $value;
		}			
	}
	if($team != "") {
	    $arrWhere[] = "team IN(" . $teamSQL . ")";
		foreach($team as $value) {
			$assWhere[":team" . $value] = $value;
		}	
	}
	if($comment != "") {
	    $arrWhere[] = "comment IN(" . $commentSQL . ")";
		foreach($comment as $value) {
			$assWhere[":comment" . $value] = $value;
		}	
	}
	if($subject != "") {
	    $arrWhere[] = "subject IN(" . $subjectSQL . ")";
		foreach($subject as $value) {
			$assWhere[":subject" . $value] = $value;
		}	
	}
	
	$arrWhere[] = "`group` IN(" . $groupSQL . ")";
	foreach($group as $value) {
		$assWhere[":group" . $value] = $value;
	}		
	$arrWhere[] = "stage IN(" . $stageSQL . ")";
	foreach($stage as $value) {
		$assWhere[":stage" . $value] = $value;
	}	
	$arrWhere[] = "round IN(" . $roundSQL . ")";
	foreach($round as $value) {
		$assWhere[":round" . $value] = $value;
	}	
	
	#$response = $assWhere;
	#throw new exception("SELECT * FROM $db_behavior WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject, round, stage");
	
	$query = $db -> prepare("SELECT count(*) FROM $db_behavior WHERE " . implode(" AND ", $arrWhere));		
	$query -> execute($assWhere); 				
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
				
	if($rows == 0) {	throw new exception("no entries matching the given parameters");	}
	else {
		
		$query = $db -> prepare("SELECT * FROM $db_behavior WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject, round, stage");		
		$query -> execute($assWhere);
		
		while($row = $query -> fetch(PDO::FETCH_ASSOC)) {
			
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['date'] = $row['date'];
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['team'] = $row['team'];
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['condition'] = $row['condition'];
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['type'] = $row['type'];
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['comment'] = $row['comment'];
			$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['RT'] = $row['RT'];
			
			for($resp = 1; $resp <= $responses; $resp++) {
				
				$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['response' . $resp] = $row['response' . $resp];
				$response['group' . $row['group']]['subject' . $row['subject']]['round' . $row['round']]['stage' . $row['stage']]['error' . $resp] = $row['error' . $resp];	
			}			
		}
		
		$query -> closeCursor(); 
	}
	
	
	// response
	
	if(empty($response)) {	throw new exception("no entries matching the given parameters");	}
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>