<?php

try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		throw new exception("round not set");
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		throw new exception("stage not set");
	}

	if(isset($_POST['responses'])) {
		$responses = $_POST['responses'];
	}
	else {
		throw new exception("responses not set");
	}

	// get optional variables
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}
	
	if(isset($_POST['condition'])) {
		$condition = $_POST['condition'];
	}
	else {
		$condition = "NULL";
		$response["warning"][] = "condition not set - set to NULL";
	}
	
	if(isset($_POST['type'])) {
		$type = $_POST['type'];
	}
	else {
		$type = "NULL";
		$response["warning"][] = "type not set - set to NULL";
	}
	
	if(isset($_POST['RT'])) {
		$RT = $_POST['RT'];
	}
	else {
		$RT = NULL;
		$response["warning"][] = "RT not set - set to NULL";
	}
		
	
	// main routine 
		
	$response_val = array();
	$error_val = array();

	for($resp = 1; $resp <= $responses; $resp++) {

		if(isset($_POST['response' . $resp])) {
			array_push($response_val, $_POST['response' . $resp]);
		}
		else {	
			array_push($response_val, "NULL");	
			$response["warning"][] = "response_val $resp not set - set to NULL";
		}

		if(isset($_POST['error' . $resp])) {	
			array_push($error_val, $_POST['error' . $resp]);	
		}
		else {	
			array_push($error_val, "NULL");	
			$response["warning"][] = "error response_val $resp not set - set to NULL";
		}
	}
	
	$date = getdate();
	$date = $date['year'] . "_". $date['mon'] . "_".  $date['mday'] . "_". $date['hours'] . "_". $date['minutes'] . "_". $date['seconds'];
	
	$db_behavior = $name . "_behavior";
	$db_round = $name . "_round";
	
	
	// get team
	
	$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject " . $subject . " not found in waiting table for group " . $group);	}
	else {	
		
		$query = $db -> prepare("SELECT team FROM $db_round WHERE `group` = :group AND subject = :subject");		
		$query -> execute(array(":subject" => $subject, ":group" => $group));
		$result = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$team = $result['team']; 
	}
		
	// add entry
	
	$query = $db -> query("SELECT count(*) FROM $db_behavior WHERE `group` = $group AND subject = $subject AND stage = $stage AND round = $round");
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows != 0) {	throw new exception("entry already exists for group $group, subject $subject, round $round, stage $stage  - no data added");	}
	else {
						
		$assWhere = array(
			":date" => $date,
		    ":group"  => $group,
		    ":subject" => $subject,
		    ":team" => $team,
			":stage" => $stage,
			":round" => $round,
			":condition" => $condition,
			":type" => $type,
			":comment" => $comment,
			":RT" => $RT
		);
				
		$query_string = "INSERT INTO $db_behavior VALUES (:date, :group, :subject, :team, :stage, :round, :condition, :type";
	
		for($resp = 0; $resp < $responses; $resp++) {
			$query_string = $query_string . ", :response" . strval($resp+1) . ", :response_error" . strval($resp+1);
			$assWhere[":response" . strval($resp+1)] = $response_val[$resp];
			$assWhere[":response_error" . strval($resp+1)] = $error_val[$resp];				
		}
		
		$query_string = $query_string . ", :comment, :RT" . ")";
								
		$query = $db -> prepare($query_string);
		$query -> execute($assWhere);
		$query -> closeCursor(); 	
	}	
	
	
	// response
	
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>