<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		$response["warning"][] = "subject not set - resetting all subjects";
		if(isset($_POST['subjects'])) {
			$subject = range(1, $subjects);
		}
		else {
			throw new exception("number of subjects not set");
		}
	}


	// main routine
	
	$db_round = $name . "_round";
	
	
	// reset
	
	$group    = (array) $group;
	$subject  = (array) $subject;
	
    $query = $db -> prepare("UPDATE $db_round SET stage = 1, round = 1 WHERE `group` = :group AND subject = :subject");
    
	foreach($group as $grp) {
		
		foreach($subject as $sub) {
    	
		 $query -> execute(array(':group' => $grp, ':subject' => $sub));
		 if($query -> rowCount() == 0) {	$response["warning"][] = "data from subject " . $sub . " (group " . $grp . ") not resetted (wrong subject/group number or already resetted?)";	}
		 
    	}
	}
	$query -> closeCursor(); 
		
	
	// response
	
	$response["result"] = "success";	
	echo json_encode($response);
		
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}




?>

