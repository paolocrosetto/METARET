<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['responses'])) {
		$responses = $_POST['responses'];
	}
	else {
		throw new exception("responses not set");
	}
	
	
	// main routine

	//function tableExists($pdo, $table) {
    //
	//    try {
	//        $result = $pdo -> query("SELECT 1 FROM $table LIMIT 1");
	//    } catch (Exception $e) {
	//        return FALSE;
	//    }
	//    return TRUE;
	//}
		
	$db_round = $name . "_round";
	$db_behaviour = $name . "_behavior";
	$db_payment = $name . "_payment";
	$db_questionnaire = $name . "_questionnaire";
	$db_final = $name . "_final";
	$db_log = $name . "_log";
	
	// create queries

	$table1 = "CREATE TABLE IF NOT EXISTS $db_round (`group` INT(4) UNSIGNED, subject INT(4) UNSIGNED, stage INT(4) UNSIGNED, round INT(4) UNSIGNED, team INT(4) UNSIGNED, part INT(4) UNSIGNED)";

	$table2 = "CREATE TABLE IF NOT EXISTS $db_behaviour (date VARCHAR(25), `group` INT(4), subject INT(4), team INT(4), stage INT(4), round INT(4), `condition` VARCHAR(30), type VARCHAR(30),";
	for ($i = 1; $i <= $responses; $i++) {	$table2 = $table2 . "response" . $i . " TEXT,";	$table2 = $table2 . "error" . $i . " TEXT,";	}
	$table2 = $table2 . "comment VARCHAR(90), RT DOUBLE)";

	$table3 = "CREATE TABLE IF NOT EXISTS $db_payment (`group` INT(4), subject INT(4), team INT(4), stage INT(4), round INT(4), earnings DOUBLE, comment VARCHAR(200))";
	$table4 = "CREATE TABLE IF NOT EXISTS $db_questionnaire (date VARCHAR(25), `group` INT(4), subject INT(4), team INT(4), label TEXT, response TEXT, comment VARCHAR(200))";
	$table5 = "CREATE TABLE IF NOT EXISTS $db_final (date VARCHAR(25), `group` INT(4), subject INT(4), team INT(4), finished VARCHAR(10), comment VARCHAR(200))";
	$table6 = "CREATE TABLE IF NOT EXISTS $db_log (date VARCHAR(25), `group` INT(4), subject INT(4), round INT(4), team INT(4), comment TEXT)";
	
	
	// execute queries
		
	//if(tableExists($db, $db_round)) {	$response["warning"][] = "table " . $db_round . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table1);
		$query -> execute();
		$query -> closeCursor(); 			
	//}
		
	
	//if(tableExists($db, $db_behaviour)) {	$response["warning"][] = "table " . $db_behaviour . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table2);
		$query -> execute();
		$query -> closeCursor(); 			
	//}
	
	//if(tableExists($db, $db_payment)) {	$response["warning"][] = "table " . $db_payment . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table3);
		$query -> execute();
		$query -> closeCursor(); 			
	//}	
	
	//if(tableExists($db, $db_questionnaire)) {	$response["warning"][] = "table " . $db_questionnaire . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table4);
		$query -> execute();
		$query -> closeCursor(); 			
	//}	
	
	//if(tableExists($db, $db_final)) {	$response["warning"][] = "table " . $db_final . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table5);
		$query -> execute();		
		$query -> closeCursor(); 	
	//}	
	
	
	//if(tableExists($db, $db_log)) {	$response["warning"][] = "table " . $db_log . " already exists – not created";	}
	//else {
		$query = $db -> prepare($table6);
		$query -> execute();	
		$query -> closeCursor(); 		
	//}	
	
	
		
	// response
	
	$response["result"] = "success";
	echo json_encode($response);
}

catch(PDOException $e) {

	$response["error"] = $e -> getMessage();
		
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
		
	echo json_encode($response);
	exit;
}


?>