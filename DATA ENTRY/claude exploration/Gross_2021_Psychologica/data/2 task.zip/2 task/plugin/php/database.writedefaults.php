<?php

// get variables

if(get_magic_quotes_gpc()) { $defaults = stripslashes($_POST['json']); }
else {	$defaults = $_POST['json'];	}
$defaults_name = $_POST['ID']; 

//$path = dirname(dirname(realpath(dirname(__DIR__)))) . "/";
$file = '../../' . $defaults_name . '.json'; 
	 
	 
// write defaults

$file_connection = fopen($file, 'w');

if($file_connection !== false) {
	
	fwrite($file_connection, $defaults);
	fclose($file_connection);
}
else {	header('HTTP/1.0 400 Bad error'); 	}
	
	
?>