<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['finished'])) {
		$finished = $_POST['finished'];
	}
	else {
		throw new exception("finished not set");
	}

	// get optional variables
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}


	// main routine	
			
	$date = getdate();
	$date = $date['year'] . "_". $date['mon'] . "_".  $date['mday'] . "_". $date['hours'] . "_". $date['minutes'] . "_". $date['seconds'];
	
	$db_final = $name . "_final";
	$db_round = $name . "_round";
	
	
	// get team
	
	$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject " . $subject . " not found in waiting table for group " . $group);	}
	else {
		
		$query = $db -> prepare("SELECT team FROM $db_round WHERE `group` = :group AND subject = :subject");		
		$query -> execute(array(":subject" => $subject, ":group" => $group));
		$result = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$team = $result['team']; 
	}
		
	
	// add entries
	
	$query = $db -> query("SELECT count(*) FROM $db_final WHERE `group` = $group AND subject = $subject");
	$rows = $query -> fetchColumn();
	$query -> closeCursor();  
	
	if($rows != 0) {	throw new exception("entry already exists for group $group, subject $subject  - no data added");	}
	else {
		
		$query_string = "INSERT INTO $db_final VALUES (:date, :group, :subject, :team, :finished, :comment)";
		
		$assWhere = array(
			":date" => $date,
		    ":group"  => $group,
		    ":subject" => $subject,
			":team" => $team,
		    ":finished" => $finished,
			":comment" => $comment
		);
		
		$query = $db -> prepare($query_string);
		$query -> execute($assWhere);
		$query -> closeCursor(); 
	}
	
		
	// response
	
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}

?>