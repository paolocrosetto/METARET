<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['rounds'])) {
		$rounds = $_POST['rounds'];
	}
	else {
		throw new exception("number of rounds not set");
	}
	
	if(isset($_POST['stages'])) {
		$stages = $_POST['stages'];
	}
	else {
		throw new exception("number of stages not set");
	}
	
	// get optional variables
	
	if(isset($_POST['onlypart'])) {
		$onlypart = $_POST['onlypart'];
	}
	else {
		$onlypart = "";
		//$response["warning"][] = "onlypart not set";
	}


	// main routine
	
	$db_round = $name . "_round";
	
	
	// increment routine
	
	$group    = (array) $group;
	$subject  = (array) $subject;
		
	for($grp = 0; $grp < count($group); $grp++) {
			
			for($sub = 0; $sub < count($subject); $sub++) {
			
				// get stage/round
			
				$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group[$grp] AND subject = $subject[$sub]");
				$rows = $query -> fetchColumn();
				$query -> closeCursor(); 
			
				if($rows == 0) {	throw new exception("subject $subject[$sub] in group $group[$grp] not in mySQL round-table. Group not initialized?\n");	}			
				else {
				
					$query = $db -> prepare("SELECT stage,round,part FROM $db_round WHERE `group` = :group AND subject = :subject");
					$query -> execute(array(':group' => $group[$grp], ':subject' => $subject[$sub]));
				
					$row = $query -> fetch(PDO::FETCH_ASSOC);
					$query -> closeCursor(); 
				
					$stage = $row['stage']; 
					$round = $row['round'];	
					$part = $row['part'];				
					
					if($onlypart == true) {
						
						$part = $part+1;
						
						$query = $db -> prepare("UPDATE $db_round SET `part` = :part WHERE `group` = :group AND subject = :subject");
						$query -> execute(array(':part' => $part, ':group' => $group[$grp], ':subject' => $subject[$sub]));					
						$query -> closeCursor(); 						
					}
					else if($stage + 1 > $stages) {
					
						$round = $round+1;
					
						$query = $db -> prepare("UPDATE $db_round SET round = :round, stage = 1 WHERE `group` = :group AND subject = :subject");
						$query -> execute(array(':round' => $round, ':group' => $group[$grp], ':subject' => $subject[$sub]));					
						$query -> closeCursor(); 
					}
					else {
					
						$stage = $stage+1;
					
						$query = $db -> prepare("UPDATE $db_round SET stage = :stage WHERE `group` = :group AND subject = :subject");
						$query -> execute(array(':stage' => $stage, ':group' => $group[$grp], ':subject' => $subject[$sub]));						
						$query -> closeCursor(); 
					}
				
					if($round > $rounds) {	$response["warning"][] = "subject $subject[$sub] in group $group[$grp] is finished";	}
				}
			}
		}
		
	
	// response
	
	echo json_encode($response);
		
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>