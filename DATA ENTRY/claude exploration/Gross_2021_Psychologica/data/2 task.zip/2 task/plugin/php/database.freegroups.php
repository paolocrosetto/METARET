<?php


try {
	
	
	include("database.php");
	$response = array();
	function array_flatten($array) {
	    $return = array();
	    foreach ($array as $key => $value) {
	        if (is_array($value)){
	            $return = array_merge($return, array_flatten($value));
	        } else {
	            $return[$key] = $value;
	        }
	    }

	    return $return;
	}


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['max'])) {
		$max = $_POST['max'];
	}
	else {
		$max = 100;
	}
	
	
	// get optional variables
	
	if(isset($_POST['condition'])) {
		$condition = $_POST['condition'];
	}
	else {
		$condition = '';
	}
	
	if(isset($_POST['type'])) {
		$type = $_POST['type'];
	}
	else {
		$type = '';
	}
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = '';
	}
	
	
	// check variables
	
	if($name === NULL) {	throw new exception("name is not set");	}
	if($max === NULL) {	throw new exception("maximum groups not set");	}
	
	$arrWhere = array();
	$assWhere = array();
	
	if($type != '') {	
		$arrWhere[] = "type = :type";
		$assWhere[":type"] = $type;		
	}
	if($comment != '') {	
		$arrWhere[] = "comment = :comment";
		$assWhere[":comment"] = $comment;		
	}
	if($condition != '') {	
		$arrWhere[] = "`condition` = :condition";
		$assWhere[":condition"] = $condition;		
	}
	
	$db_behavior = $name . "_behavior";
	
	for ($i = 1; $i <= $max; ++$i) {	$response[] = $i;		}
	
	// get groups
	
	if(count($arrWhere) > 0) {		
				
		$query = $db -> prepare("SELECT DISTINCT `group` FROM $db_behavior WHERE " . implode(" AND ", $arrWhere));		
		$query -> execute($assWhere);
	}
	else {
	
		$query = $db -> prepare("SELECT DISTINCT `group` FROM $db_behavior");
		$query -> execute();
	}

	$result = $query -> fetchAll();
	
	foreach($result as $val) {
		
		unset($response[($val[0]-1)]);
	}
	
	$query -> closeCursor(); 
		
	// response
	
	$response = array_values($response);
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
	

?>