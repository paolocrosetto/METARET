<?php



try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	// get optional variables
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		$subject = "";
		$response["warning"][] = "subject not set";
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		$round = "";
		$response["warning"][] = "round not set";
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		$stage = "";
		$response["warning"][] = "stage not set";
	}

	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}
	
	if(isset($_POST['team'])) {
		$team = $_POST['team'];
	}
	else {
		$team = "";
		$response["warning"][] = "team not set";
	
	}
	
	if(isset($_POST['aggregate'])) {
		$aggregate = $_POST['aggregate'];
	}
	else {
		$team = "";
		$response["warning"][] = "aggregate not set";
	
	}

	
	// main routine
	
	$group  = (array) $group; $groupSQL = ":group" . implode(", :group", $group);
	
	if($subject != "") {	$subject = (array) $subject; $subjectSQL = ":subject" . implode(", :subject", $subject);	}
	if($stage != "") {		$stage = (array) $stage; $stageSQL = ":stage" . implode(", :stage", $stage);	}
	if($round != "") {		$round = (array) $round; $roundSQL = ":round" . implode(", :round", $round);	}
	if($team != "") {	$team = (array) $team; $teamSQL = ":team" . implode(", :team", $team);	}
	if($comment != "") {	$comment = (array) $comment; $commentSQL = ":comment" . implode(", :comment", $comment);	}
	
	$db_payment = $name . "_payment";
	
	
	// get earnings
	
	$arrWhere = array();
	$assWhere = array();
	
	if($subject != "") {
	    $arrWhere[] = "subject IN(" . $subjectSQL . ")";
		foreach($subject as $value) {
			$assWhere[":subject" . $value] = $value;
		}			
	}
	if($stage != "") {
	    $arrWhere[] = "stage IN(" . $stageSQL . ")";
		foreach($stage as $value) {
			$assWhere[":stage" . $value] = $value;
		}	
	}
	if($round != "") {
	    $arrWhere[] = "round IN(" . $roundSQL . ")";
		foreach($round as $value) {
			$assWhere[":round" . $value] = $value;
		}	
	}
	if($team != "") {
	    $arrWhere[] = "team IN(" . $teamSQL . ")";
		foreach($team as $value) {
			$assWhere[":team" . $value] = $value;
		}	
	}
	if($comment != "") {
	    $arrWhere[] = "comment IN(" . $commentSQL . ")";
		foreach($comment as $value) {
			$assWhere[":comment" . $value] = $value;
		}	
	}
	$arrWhere[] = "`group` IN(" . $groupSQL . ")";
	foreach($group as $value) {
		$assWhere[":group" . $value] = $value;
	}	
	
	if($aggregate == "true") {
				
		$query = $db -> prepare("SELECT count(*) FROM $db_payment WHERE " . implode(" AND ", $arrWhere));		
		$query -> execute($assWhere); 				
		$rows = $query -> fetchColumn();
		$query -> closeCursor(); 
		
		if($rows == 0) {	throw new exception("no entries matching the given parameters");	}
		else {
			
			$query = $db -> prepare("SELECT SUM(earnings) FROM $db_payment WHERE " . implode(" AND ", $arrWhere));		
			$query -> execute($assWhere);
			
			$result = $query -> fetch(PDO::FETCH_ASSOC);
			$result = $result['SUM(earnings)'];		
						
			$query -> closeCursor(); 
			
			#if(is_null($result)) {	throw new exception("no entries matching the given parameters");	}
			$response = $result;	
		}	
	}
	else {
		
		$query = $db -> prepare("SELECT count(*) FROM $db_payment WHERE " . implode(" AND ", $arrWhere));		
		$query -> execute($assWhere); 				
		$rows = $query -> fetchColumn();
		$query -> closeCursor(); 
		
		if($rows == 0) {	throw new exception("no entries matching the given parameters");	}
		else {
			
			$query = $db -> prepare("SELECT * FROM $db_payment WHERE " . implode(" AND ", $arrWhere));		
			$query -> execute($assWhere);
						
			while($result = $query -> fetch(PDO::FETCH_ASSOC)) {
				$response['group' . $result['group']]['subject' . $result['subject']]['round' . $result['round']]['stage' . $result['stage']] = $result['earnings'];		
				$response['group' . $result['group']]['subject' . $result['subject']]['round' . $result['round']]['stage' . $result['stage'] . 'comment'] = $result['comment'];		
				
			}
			
			$query -> closeCursor(); 
		}		
	}
		
	
	// response
	
	if(empty($response) && $response != 0) {	throw new exception("no entries matching the given parameters");	}
	echo json_encode($response);
		
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>