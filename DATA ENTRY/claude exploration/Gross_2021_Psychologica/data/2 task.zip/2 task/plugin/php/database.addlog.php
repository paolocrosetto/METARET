<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		throw new exception("round not set");
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		throw new exception("stage not set");
	}

	// get optional variables
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}

	
	// main routine
	
	$date = getdate();
	$date = $date['year'] . "_". $date['mon'] . "_".  $date['mday'] . "_". $date['hours'] . "_". $date['minutes'] . "_". $date['seconds'];
	
	$db_log = $name . "_log";
	$db_round = $name . "_round";
	
	$comment = (array) $comment;
	
	
	// get team
	
	$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject " . $subject . " not found in waiting table for group " . $group);	}
	else {	
		
		$query = $db -> prepare("SELECT team FROM $db_round WHERE `group` = :group AND subject = :subject");		
		$query -> execute(array(":subject" => $subject, ":group" => $group));

		$result = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$team = $result['team']; 
	}
	
		
	// add entry
	
	for($x = 0; $x < count($comment); $x++) {
				
		$assWhere = array(
			":date" => $date,
		    ":group"  => $group,
		    ":subject" => $subject,
			":round" => $round,
			":team" => $team,
			":comment" => $comment[$x]
		);
			
		$query_string = "INSERT INTO $db_log VALUES (:date, :group, :subject, :round, :team, :comment)";
			
		$query = $db -> prepare($query_string);
		$query -> execute($assWhere);	
		$query -> closeCursor(); 
	}
	
	
	// response
	
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>