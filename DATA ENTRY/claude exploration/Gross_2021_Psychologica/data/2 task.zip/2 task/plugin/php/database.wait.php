<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['waitfor'])) {
		$waitfor = $_POST['waitfor'];
	}
	else {
		throw new exception("waitfor not set");
	}

	
	// main routine
	
	$waiting = false;
	if($waitfor === NULL) {	throw new exception("waitfor not set");	}
	
	$db_round = $name . "_round";
	
	if($waitfor != "team" && $waitfor != "group") {
		$waitfor = (array) $waitfor;
		if(!ctype_digit(implode('', $waitfor))) {	throw new exception("non-numeric entries passed to waitfor");	}
		if(in_array($subject, $waitfor)) {	throw new exception("waitfor contains subject – subject can not wait for itself");		}
	}
	
	
	// wait procedure
	
	$arrWhere = array();
	$assWhere = array();
	
	$assWhere[":group"] = $group;	
	$assWhere[":subject"] = $subject;	
	
	
	$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group AND subject = $subject");
	$query -> execute($assWhere); 				
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject or group not in mySQL round-table. Group not initialized?");	}
	else {
		
		$query = $db -> prepare("SELECT stage,round,team FROM $db_round WHERE `group` = :group AND subject = :subject");
		$query -> execute($assWhere);
				
		$result = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$stage = $result['stage'];		
		$round = $result['round'];
		$team = $result['team'];
	}
		
	
	if($waitfor == 'team') {
		$assWhere[":team"] = $team;	
		if($assWhere[":team"] == null) {	throw new exception("teams not specified");	}
		$query_string = "SELECT stage,round FROM $db_round WHERE `group` = :group AND subject != :subject AND team = :team";		
	}
	else if($waitfor == 'group') {
		$query_string = "SELECT stage,round FROM $db_round WHERE `group` = :group AND subject != :subject";		
	}
	else {		
		$query_string = "SELECT stage,round FROM $db_round WHERE `group` = :group AND subject != :subject AND subject IN (:subjects)";		
		$assWhere[":subjects"] = join(',', $waitfor);
	}
	
		
	$query = $db -> prepare($query_string);		
	$query -> execute($assWhere);
	
	while($row = $query -> fetch(PDO::FETCH_ASSOC)) {
		
		#throw new exception($row['round'] . "___" . $round);
		#throw new exception($row['stage'] . "___" . $stage);
					
		if($row['stage'] < $stage && $row['round'] == $round) { 	$waiting = true;	}
		if($row['round'] < $round) { 	$waiting = true;	}
		
		#$converted_waiting = ($waiting) ? 'true' : 'false';
		#throw new exception('xxx' . $converted_waiting);
		
		#$converted_bool = ($row['stage'] < $stage) ? 'true' : 'false';
		#throw new exception($stage);
		#throw new exception($row['round'] == $round);
		
	}
	
	$query -> closeCursor(); 	
	$response["result"] = $waiting;
	
	// response
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>