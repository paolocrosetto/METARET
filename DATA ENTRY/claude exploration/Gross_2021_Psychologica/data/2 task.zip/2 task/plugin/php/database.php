<?php

try {
		
	// localhost
	$db = new PDO('mysql:host=localhost; dbname=mysql; charset=utf8', 'root', 'root');	

	$db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db -> setAttribute(PDO::ATTR_EMULATE_PREPARES, false);	
	$db -> setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);	
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>