<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}


	// main routine	

	$db_round = $name . "_round";
	
	// redirect
	
	$query = $db -> prepare("SELECT stage FROM $db_round WHERE `group` = :group AND subject = :subject");		
	$query -> execute(array(':group' => $group, ':subject' => $subject)); 				

	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
	
	if($rows == 0) {	throw new exception("subject or group not in mySQL round-table. Group not initialized?");	}
	else {
		
		$query = $db -> prepare("SELECT stage,part FROM $db_round WHERE `group` = :group AND subject = :subject");		
		$query -> execute(array(':group' => $group, ':subject' => $subject));
				
		$status = $query -> fetch(PDO::FETCH_ASSOC);
		$query -> closeCursor(); 
		
		$stage = $status['stage'];
		$part = $status['part'];
		
		$response["stage"] = $stage;
		$response["part"] = $part;
	}
	
	
	// response
	
	echo json_encode($response);
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>