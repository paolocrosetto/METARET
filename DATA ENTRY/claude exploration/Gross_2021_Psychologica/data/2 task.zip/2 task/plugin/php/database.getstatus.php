<?php


try {
	

	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	// optional variables
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		$subject = "";
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		$round = "";
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		$stage = "";
	}
	if(isset($_POST['team'])) {
		$team = $_POST['team'];
	}
	else {
		$team = "";
	}

	
	// main routine
		
	$group  = (array) $group; $groupSQL = ":group" . implode(", :group", $group);
	
	if($subject != "") {	$subject = (array) $subject; $subjectSQL = ":subject" . implode(", :subject", $subject);	}
	if($stage != "") {		$stage = (array) $stage; $stageSQL = ":stage" . implode(", :stage", $stage);	}
	if($round != "") {		$round = (array) $round; $roundSQL = ":round" . implode(", :round", $round);	}
	if($team != "") {	$team = (array) $team; $teamSQL = ":team" . implode(", :team", $team);	}
	
	$db_round = $name . "_round";
	
	
	// get earnings
	
	$arrWhere = array();
	$assWhere = array();
	
	if($subject != "") {
	    $arrWhere[] = "subject IN(" . $subjectSQL . ")";
		foreach($subject as $value) {
			$assWhere[":subject" . $value] = $value;
		}			
	}
	if($stage != "") {
	    $arrWhere[] = "stage IN(" . $stageSQL . ")";
		foreach($stage as $value) {
			$assWhere[":stage" . $value] = $value;
		}	
	}
	if($round != "") {
	    $arrWhere[] = "round IN(" . $roundSQL . ")";
		foreach($round as $value) {
			$assWhere[":round" . $value] = $value;
		}	
	}
	if($team != "") {
	    $arrWhere[] = "team IN(" . $teamSQL . ")";
		foreach($team as $value) {
			$assWhere[":team" . $value] = $value;
		}	
	}
	$arrWhere[] = "`group` IN(" . $groupSQL . ")";
	foreach($group as $value) {
		$assWhere[":group" . $value] = $value;
	}	
			
	$query = $db -> prepare("SELECT count(*) FROM $db_round WHERE " . implode(" AND ", $arrWhere));		
	$query -> execute($assWhere); 				
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
				
	if($rows == 0) {	throw new exception("no entries matching the given parameters");	}
	else {
		
		$query = $db -> prepare("SELECT * FROM $db_round WHERE " . implode(" AND ", $arrWhere) . " ORDER BY subject");		
		$query -> execute($assWhere);
				
		while($result = $query -> fetch(PDO::FETCH_ASSOC)) {
			$response['group' . $result['group']]['subject' . $result['subject']]['round'] = $result['round'];		
			$response['group' . $result['group']]['subject' . $result['subject']]['stage'] = $result['stage'];	
			$response['group' . $result['group']]['subject' . $result['subject']]['team'] = $result['team'];	
			$response['group' . $result['group']]['subject' . $result['subject']]['part'] = $result['part'];
		}
		
		$query -> closeCursor(); 
	}		
	
	
	// response
	
	if(empty($response)) {	throw new exception("no entries matching the given parameters");	}
	echo json_encode($response);
		
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>