<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	// get optional variables
	
	$get_groups = false;
	if(isset($_POST['groups'])) {
		$group = $_POST['groups'];
	}
	else {
		$get_groups = true;
	}
	

	// main routine
	
	$db_round = $name . "_round";
	$db_final = $name . "_final";
	
	if($get_groups == true) {
				
		$query = $db -> prepare("SELECT DISTINCT `group` FROM $db_round");		
		$query -> execute();
		
		while($row = $query -> fetch(PDO::FETCH_ASSOC)) {	$group[] = $row['group'];		}
		$query -> closeCursor(); 	
	}
	
	$group  = (array) $group; $groupSQL = ":group" . implode(", :group", $group);
	
	
	// get round, team, group, subject
	
	$arrWhere = array();
	$assWhere = array();
	
	$arrWhere[] = "`group` IN(" . $groupSQL . ")";
	foreach($group as $value) {
		$assWhere[":group" . $value] = $value;
	}
	
		
	$query = $db -> prepare("SELECT `group`,subject,team,round FROM $db_round WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject");
	$query -> execute($assWhere);
	
	while($row = $query -> fetch(PDO::FETCH_ASSOC)) {

		$response['group' . $row['group']]['subject' . $row['subject']]['team'] = $row['team'];
		$response['group' . $row['group']]['subject' . $row['subject']]['round'] = $row['round'];
	}
	$query -> closeCursor(); 
	
	
	// get finished, comment
	
	$query = $db -> prepare("SELECT `group`,subject,finished,comment FROM $db_final WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject");		
	$query -> execute($assWhere);
	
	while($row = $query -> fetch(PDO::FETCH_ASSOC)) {

		$response['group' . $row['group']]['subject' . $row['subject']]['comment'] = $row['comment'];
		$response['group' . $row['group']]['subject' . $row['subject']]['finished'] = $row['finished'];
	}
	$query -> closeCursor(); 
	
	// response
	
	if(empty($response)) {	throw new exception("no entries matching the given parameters");	}
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>