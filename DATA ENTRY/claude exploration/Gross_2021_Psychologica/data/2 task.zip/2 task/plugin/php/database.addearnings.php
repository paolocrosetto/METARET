<?php


try {
	
	include("database.php");
	$response = array();

	
	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		throw new exception("subject not set");
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		throw new exception("round not set");
	}
	
	if(isset($_POST['stage'])) {
		$stage = $_POST['stage'];
	}
	else {
		throw new exception("stage not set");
	}
	
	// get optional variables
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}
	
	if(isset($_POST['earnings'])) {
		$earnings = $_POST['earnings'];
	}
	else {
		$earnings = 0;
		$response["warning"][] = "earnings not set - set to 0";
	}
		
	
	// main routine
	
	if(count($earnings) != (count($group) * count($subject) * count($round) * count($stage))) {	throw new exception("earning vector too short");	}
	
	$db_round = $name . "_round";
	$db_payment = $name . "_payment";
	
	
	// add earnings
		
	$group    = (array) $group;
	$subject  = (array) $subject;
	$stage    = (array) $stage;
	$round    = (array) $round;
	$earnings = (array) $earnings;
	
	$i = 0;
	
	for($grp = 0; $grp < count($group); $grp++) {
		
		for($sub = 0; $sub < count($subject); $sub++) {
	
			// get team
						
			$query = $db -> query("SELECT count(*) FROM $db_round WHERE `group` = $group[$grp] AND subject = $subject[$sub]");
			$rows = $query -> fetchColumn();
			$query -> closeCursor(); 	
			
			if($rows == 0) {	throw new exception("subject " . $subject[$sub] . " not found in waiting table for group " . $group[$grp]);	}
			else {	
				
				$query = $db -> prepare("SELECT team FROM $db_round WHERE `group` = :group AND subject = :subject");		
				$query -> execute(array(":subject" => $subject[$sub], ":group" => $group[$grp]));
				$result = $query -> fetch(PDO::FETCH_ASSOC);
				$query -> closeCursor(); 
				
				$team = $result['team']; 
			}
				
			for($rnd = 0; $rnd < count($round); $rnd++) {
			
				for($stg = 0; $stg < count($stage); $stg++) {
												
					$earn = $earnings[$i];
						
					$query = $db -> query("SELECT count(*) FROM $db_payment WHERE `group` = $group[$grp] AND subject = $subject[$sub] AND stage = $stage[$stg] AND round = $round[$rnd]");		
					$rows = $query -> fetchColumn();
					$query -> closeCursor(); 
					
					if($rows > 0) {	$response["warning"][] = "entry already in database for group $group[$grp], subject $subject[$sub], round $round[$rnd], stage $stage[$stg] - no data added"; }
					else {
											
						$query = $db -> prepare("INSERT INTO $db_payment VALUES (:group, :subject, :team, :stage, :round, :earning, :comment)");		
						$query -> execute(array(":group" => $group[$grp], ":subject" => $subject[$sub], ":team" => $team, ":stage" => $stage[$stg], ":round" => $round[$rnd], ":earning" => $earn, ":comment" => $comment));				
						$query -> closeCursor(); 
						
						$i = $i+1;				
					}
	
				}			
			}	
		}	
	}
		
	
	// response
	
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>