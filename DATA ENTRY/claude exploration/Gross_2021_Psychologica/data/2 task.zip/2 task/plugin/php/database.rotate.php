<?php


try {
	
	include("database.php");
	$response = array();


	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}
	
	if(isset($_POST['round'])) {
		$round = $_POST['round'];
	}
	else {
		throw new exception("round not set");
	}

	if(isset($_POST['team_moving_location'])) {
		$team_moving_location = $_POST['team_moving_location'];
	}
	else {
		throw new exception("team_moving_location not set");
	}
	
	if(isset($_POST['team_moving'])) {
		$team_moving = $_POST['team_moving'];
	}
	else {
		throw new exception("team_moving not set");
	}

	if(isset($_POST['subject_moving'])) {
		$subject_moving = $_POST['subject_moving'];
	}
	else {
		throw new exception("subject_moving not set");
	}
	
	
	// main routine
	
	$db_round = $name . "_round";
	$db_behavior = $name . "_behavior";
	
	//if(count($team_moving) > 2) {
		
	for($x = 0; $x < count($subject_moving); $x++) {
	    
		
		$query = $db -> prepare("UPDATE $db_round SET team = :team WHERE subject = :subject AND `group` = :group");		
		$query -> execute(array(
		    ":team" => $team_moving_location[$x],
		    ":subject" => $subject_moving[$x],
			":group" => $group
		));
		$query -> closeCursor(); 
		
		//$query = $db -> prepare("UPDATE $db_behavior SET comment = :comment WHERE team = :team AND `group` = :group AND round = :round");		
		//$query -> execute(array(
		//    ":comment" => 'rematched',
		//    ":team" => $team_moving[$x],
		//	":group" => $group,
		//	":round" => $round
		//));
		
		
	} 
	//}
	//else {
	//	
	//	for($x = 0; $x <= count($subject_moving); $x++) {
	//	    			
	//		$query = $db -> prepare("UPDATE $db_behavior SET comment = :comment WHERE team = :team AND `group` = :group AND round = :round");		
	//		$query -> execute(array(
	//		    ":comment" => 'impossible',
	//		    ":team" => $team_moving[$x],
	//			":group" => $group,
	//			":round" => $round
	//		));
	//		
	//		
	//	} 		
	//}
	
	//throw new exception(".." . $single_teams[0] . $single_teams[1] );
	#$response["warning"] = ".." . $single_teams[0] . $single_teams[1];
		
	
	// response
	
	$response["warning"][] = "UPDATE $db_round SET team = :team WHERE subject = :subject AND `group` = :group";
	$response["warning"][] = "UPDATE $db_behavior SET comment = :comment WHERE team = :team AND `group` = :group AND round = :round";
	$response["warning"][] = 'moving:' . $team_moving[0] . '__' . $group . '___location:' . $team_moving_location[0] . '___round:' . $round;
	$response["warning"][] = 'moving:' . $team_moving[1] . '__' . $group . '___location:' . $team_moving_location[1];
	
	
	$response["result"] = "success";
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
	

?>


