<?php


try {
	
	include("database.php");
	$response = array();
	
	
	// get mandatory variables
	
	if(isset($_POST['name'])) {
		$name = $_POST['name'];
	}
	else {
		throw new exception("name not set");
	}
	
	if(isset($_POST['group'])) {
		$group = $_POST['group'];
	}
	else {
		throw new exception("group not set");
	}

	// get optional variables
	
	if(isset($_POST['label'])) {
		$label = $_POST['label'];
	}
	else {
		$label = "";
		$response["warning"][] = "label not set";
	}
	
	if(isset($_POST['subject'])) {
		$subject = $_POST['subject'];
	}
	else {
		$subject = "";
		$response["warning"][] = "subject not set";
	}
	
	if(isset($_POST['comment'])) {
		$comment = $_POST['comment'];
	}
	else {
		$comment = "";
		$response["warning"][] = "comment not set";
	}
	
	if(isset($_POST['team'])) {
		$team = $_POST['team'];
	}
	else {
		$team = "";
		$response["warning"][] = "team not set";
	
	}
	
	if(isset($_POST['condition'])) {
		$condition = $_POST['condition'];
	}
	else {
		$condition = "";
		$response["warning"][] = "condition not set";
	
	}
	
	// main routine
	
	$group  = (array) $group; $groupSQL = ":group" . implode(", :group", $group);
	
	if($subject != "") {		$subject  = (array) $subject; $subjectSQL = ":subject" . implode(", :subject", $subject);	}
	if($condition != "") {		$condition = (array) $condition; $conditionSQL = ":condition" . implode(", :condition", $condition);	}	
	if($comment != "") {	$comment = (array) $comment; $commentSQL = ":comment" . implode(", :comment", $comment);	}
	if($team != "") {	$team = (array) $team; $teamSQL = ":team" . implode(", :team", $team);	}
	if($label != "") {	$label = (array) $label; $labelSQL = ":label" . implode(", :label", $label);	}
	
	$db_questionnaire = $name . "_questionnaire";


	// read procedure
	
	$arrWhere = array();
	$assWhere = array();
	
	if($team != "") {
	    $arrWhere[] = "team IN(" . $teamSQL . ")";
		foreach($team as $value) {
			$assWhere[":team" . $value] = $value;
		}	
	}
	if($comment != "") {
	    $arrWhere[] = "comment IN(" . $commentSQL . ")";
		foreach($comment as $value) {
			$assWhere[":comment" . $value] = $value;
		}	
	}
	if($subject != "") {
	    $arrWhere[] = "subject IN(" . $subjectSQL . ")";
		foreach($subject as $value) {
			$assWhere[":subject" . $value] = $value;
		}	
	}
	if($label != "") {
	    $arrWhere[] = "label IN(" . $labelSQL . ")";
		foreach($label as $value) {
			$assWhere[":label" . $value] = $value;
		}	
	}
	
	$arrWhere[] = "`group` IN(" . $groupSQL . ")";
	foreach($group as $value) {
		$assWhere[":group" . $value] = $value;
	}		
		
		
	#$response = $assWhere;
	#throw new exception("SELECT * FROM $db_questionnaire WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject, round, stage");
	
	$query = $db -> prepare("SELECT count(*) FROM $db_questionnaire WHERE " . implode(" AND ", $arrWhere));		
	$query -> execute($assWhere); 				
	$rows = $query -> fetchColumn();
	$query -> closeCursor(); 
				
	if($rows == 0) {	throw new exception("no entries matching the given parameters");	}
	else {
		
		$query = $db -> prepare("SELECT * FROM $db_questionnaire WHERE " . implode(" AND ", $arrWhere) . " ORDER BY `group`, subject");		
		$query -> execute($assWhere);
		
		while($row = $query -> fetch(PDO::FETCH_ASSOC)) {
			
			$response['group' . $row['group']]['subject' . $row['subject']][$row['label']]['date'] = $row['date'];
			$response['group' . $row['group']]['subject' . $row['subject']][$row['label']]['team'] = $row['team'];
			$response['group' . $row['group']]['subject' . $row['subject']][$row['label']]['response'] = $row['response'];
			$response['group' . $row['group']]['subject' . $row['subject']][$row['label']]['comment'] = $row['comment'];		
		}
		
		$query -> closeCursor(); 
	}
	
	
	// response
	
	if(empty($response)) {	throw new exception("no entries matching the given parameters");	}
	echo json_encode($response);
	
}

catch(PDOException $e) {
	
	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}
catch(exception $e) {

	$response["error"] = $e -> getMessage();
	echo json_encode($response);
	exit;
}


?>