(function($) {
		
	
	$.jgames = function(options) {
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		jQuery.each(opts, function(name, value) {
		    console.log(name + ": " + value)
		})
		
		this.defaults = opts
		return self
	
	}
	
	$.jgames.defaults = {
		
		teams: 1,
		rounds: 1,
		stages: 1,
		
		use_defaults: true,
		plugin_path: 'plugin/',
		show_errors: false,
		wait_interval: 4000,
		export_method: 'client',
		redirect_extension: 'html',
		aggregate_earnings: true,
		global_defaults: false,
		
		fading_speed: 1000,
		update_inputerror: true,
		load_extension: "html"		
	}
	
	$.jgames.content = {}
	
	
	$.jgames.create = function(options) {
		
		var function_name = '$.jgames.create'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['responses']).primary !== 'integer')	{
			
			error(function_name, 'error', 'responses not set or invalid')
			return 	
		}
						
		var response_promise = $.ajax({
			method: "POST",
			url: this.defaults['plugin_path'] + "php/database.create.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
		
	    return response_promise
	}
	
	$.jgames.initgroup = function(options) {
		
		var function_name = '$.jgames.initgroup'

		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subjects']).primary !== 'integer') {
			
			error(function_name, 'error', 'subjects not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['team_assignment'] !== 'undefined') {
			
			if(check(opts['team_assignment']).secondary !== 'array' || check(opts['team_assignment']).primary != 'integer') {
				
				error(function_name, 'error', 'groups must be specified as an array containing only integers')
				return
			}
			else if(check(opts['team_assignment']).length != opts['subjects']) {
				
				error(function_name, 'error', 'groups array length does not match number of subjects')
				return
			}
		}
				
		var response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.initgroup.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
		
	    return response_promise
	}
			
	
	$.jgames.increment = function(options) {
				
		var function_name = '$.jgames.increment'

		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['stages']).primary !== 'integer') {
			
			error(function_name, 'error', 'stages not set or invalid')
			return 	
		}
		else if(check(opts['rounds']).primary !== 'integer') {
			
			error(function_name, 'error', 'rounds not set or invalid')
			return 	
		}
				
		response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.increment.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
				else if(opts['onlypart'] == true)	console.log('notice: part incremented');
				else 	console.log('notice: stage/round incremented');

			}					
		})
				
	    return response_promise
		
	}
	
	$.jgames.reset = function(options) {
			
		var function_name = '$.jgames.reset'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		
		response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.reset.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}					
		})
		
		return response_promise		
			
	}
	
	$.jgames.wait = function(options) {
	
		var function_name = '$.jgames.wait'
		
		var def = $.Deferred()
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
				
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['waitfor']).primary !== 'integer' && opts['waitfor'] !== 'team' && opts['waitfor'] !== 'group') {
			
			error(function_name, 'error', 'waitfor not set or invalid')
			return 	
		}
				
		var loop = setInterval(function() {
			
			$.ajax({
				method: "POST",
				url: opts['plugin_path'] + "php/database.wait.php",
				dataType: "json",
				data: opts,
				error: function(XMLHttpRequest, textStatus, errorThrown) {	
					error(function_name, 'error', errorThrown) 	
					clearInterval(loop)
				},
				success: function(data) {
				
					if(data.error)	{
						error(function_name, 'error', data.error)
						clearInterval(loop)
					}
					else if(data.warning)	error(function_name, 'warning', data.warning)	
										
					if("result" in data) {
						if(data.result == false) {
							console.log("notice: waiting finished")
							
							if(opts['redirect'] == true)	this.redirect({ destination: 'next stage', group: opts['group'], subject: opts['subject'] })
							
							clearInterval(loop)
							def.resolve()					
						} 
						else if(data.result == true)	console.log("notice: waiting ...")
					}			
				}					
			});				
		
		}, opts['wait_interval'])

		return def.promise()	
	
	}
	
	$.jgames.redirect = function(options) {
				
		var function_name = '$.jgames.redirect'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
												
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['destination'] !== 'undefined' && check(opts['destination']).primary !== 'string') {
			
			error(function_name, 'error', 'destination invalid')
			return 			
		}
		
				
		if(typeof opts['destination'] === 'undefined' || opts['destination'] == "next stage") {
							
			$.ajax({
				method: "POST",
				url: opts['plugin_path'] + "php/database.redirect.php",
				dataType: "json",
				data: opts,
				error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
				success: function(data)	{
					
					if(data.error)	error(function_name, 'error', data.error)	
					else if(data.warning)	error(function_name, 'warning', data.warning)	
						
					if("stage" in data && "part" in data) {
						
						console.log(data)
						
						var ID = opts['name'] + "_" + opts['subject'] + "_" + opts['group'];
						console.log('notice: redirecting to current part/stage');
						
						//window.location.replace('part' + data.part + '_stage' + data.stage + '.' + opts['redirect_extension'] + '?id=' + ID);
						window.location.replace(opts['parts'][data.part-1] + '_stage' + data.stage + '.' + opts['redirect_extension'] + '?id=' + ID);
					}						
				}		
			})
				
		}
		else {
			
		    console.log('notice: redirecting');
			var ID = opts['name'] + "_" + opts['subject'] + "_" + opts['group'];
			window.location.replace(opts['destination'] + '.' + opts['redirect_extension'] + '?id=' + ID); 
		}	
	
	}
	
	
	$.jgames.getID = function(options) {
				
		var function_name = '$.jgames.getID'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
			
		var ID = getQueryVariable('id')
		
		if(ID == '')	error(function_name, 'error', 'ID not appended to URL')
		else {
			
			ID = ID.split("_")
			opts['name'] = ID[0]
			opts['subject'] = parseInt(ID[1])
			opts['group'] = parseInt(ID[2])
			
			this.defaults = opts
			
			console.log("notice: subject and group ID parsed to defaults")
		}
		
		return self
		
	}
	
	$.jgames.importdefaults = function(options) {
		
		var function_name = '$.jgames.importdefaults'
		
		var def = $.Deferred()
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(opts['global_defaults'] == false && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 
		}
		else if(opts['global_defaults'] == false && check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['file']).primary !== 'string') {
			
			error(function_name, 'error', 'file not set or invalid')
			return 	
		}
		
		// get ID
		if(opts['global_defaults'] == false)	var ID = opts['file'] + "_" + opts['subject'] + "_" + opts['group'] + "_defaults"
		else 	var ID = opts['file'] + "_defaults"
		
		
		// get cookie		
		if(opts['export_method'] == 'cookie') {
			
			if(getCookie(ID)) {
			
				opts = $.extend({}, opts, JSON.parse(getCookie(ID)))
				$.jgames.defaults = opts
				console.log('notice: defaults imported from cookie')
			}
			else 	error(function_name, 'error', 'cookie not found')
			
			def.resolve(); 
		}	
		
		// get file on server
		else if(opts['export_method'] == 'server') {
								
			$.getJSON(ID + '.json').done(function(data) {
				
				opts = $.extend({}, opts, data)
				$.jgames.defaults = opts
				console.log('notice: defaults imported from JSON file')
				def.resolve()
				
			}).fail(function() {	
				error(function_name, 'error', 'defaults file not found or unreadable')	
			})
		}
		
		// get HTML5 local storage
		else if(opts['export_method'] == 'client') {
			
			data = jQuery.parseJSON(localStorage.getItem(ID))
						
			if(data == undefined) {
				$.getJSON(ID + '.json').done(function(data) {
				
					opts = $.extend({}, opts, data)
					$.jgames.defaults = opts
					console.log('notice: defaults not in local storage - defaults imported from JSON file on the server side')
					def.resolve()
				
				}).fail(function() {	
					error(function_name, 'error', 'defaults file not found or unreadable')	
				})
			}
			else {
				
				opts = $.extend({}, opts, data)
				$.jgames.defaults = opts
				console.log('notice: defaults imported from local storage')
				def.resolve()	
			}
		}
		
		return def.promise()
		
	}
		
	$.jgames.exportdefaults = function(options) {
	
		var function_name = '$.jgames.exportdefaults'
		
		var def = $.Deferred();
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(opts['global_defaults'] == false && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 
		}
		else if(opts['global_defaults'] == false && check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['file']).primary !== 'string') {
			
			error(function_name, 'error', 'file not set or invalid')
			return 	
		}
		
		// get ID
		if(opts['global_defaults'] == false)	var ID = opts['file'] + "_" + opts['subject'] + "_" + opts['group'] + "_defaults" 
		else 	var ID = opts['file'] + "_defaults"
				
		// save cookie
		if(opts['export_method'] == 'cookie') {
			
			var stringObj = JSON.stringify(opts)
			if(setCookie(stringObj, 1, ID))	console.log('notice: defaults-cookie created (valid for one day)')
			def.resolve()
		}
		
		// save file on server
		else if(opts['export_method'] == 'server') {
						
			$.ajax({
				method: "POST",
				url: opts['plugin_path'] + "php/database.writedefaults.php",
				data: { json: JSON.stringify(opts), ID: ID }
			}).done(function(data) {
				
				console.log('notice: defaults-file created')
				def.resolve()
				
			}).fail(function() {				
				error(function_name, 'error', 'defaults file could not be created - check for permission problem or wrongly specified path/filename')	
			})
		
		}
		
		// save using HTML5 localstorage
		else if(opts['export_method'] == 'client') {
			
			if(typeof(Storage) !== "undefined") {
				localStorage.setItem(ID, JSON.stringify(opts))
				console.log('notice: defaults-storage created')
				def.resolve()
			}
			else {
				error(function_name, 'error', 'defaults file could not be created - no HTML5 local storage support?')	
			}
		}		
		
		
		return def.promise()
		
	}
	
	$.jgames.importcontent = function(options) {
	
		var function_name = '$.jgames.importcontent'
	
		var def = $.Deferred()
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_content === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_content == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
	
		// mandatory
		if(opts['global_content'] == false && check(opts['subject']).primary !== 'integer') {
		
			error(function_name, 'error', 'subject not set or invalid')
			return 
		}
		else if(opts['global_content'] == false && check(opts['group']).primary !== 'integer') {
		
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['file']).primary !== 'string') {
		
			error(function_name, 'error', 'file not set or invalid')
			return 	
		}
	
		// get ID
		if(opts['global_content'] == false)	var ID = opts['file'] + "_" + opts['subject'] + "_" + opts['group'] + "_content"
		else 	var ID = opts['file'] + "_content"
		
		// get cookie		
		if(opts['export_method'] == 'cookie') {
		
			if(getCookie(ID)) {
								
				$.jgames.content = $.extend({}, $.jgames.content, JSON.parse(getCookie(ID)))
				console.log('notice: content imported from cookie')
			}
			else 	error(function_name, 'error', 'cookie not found')
		
			def.resolve(); 
		}	
	
		// get file on server
		else if(opts['export_method'] == 'server') {
							
			$.getJSON(ID + '.json').done(function(data) {
			
				$.jgames.content = $.extend({}, $.jgames.content, data)
				console.log('notice: content imported from JSON file')
				def.resolve()
			
			}).fail(function() {	
				error(function_name, 'error', 'content file not found or unreadable')	
			})
		}
	
		// get HTML5 local storage
		else if(opts['export_method'] == 'client') {
		
			data = jQuery.parseJSON(localStorage.getItem(ID))
					
			if(data == undefined) {
				$.getJSON(ID + '.json').done(function(data) {
			
					$.jgames.content = $.extend({}, $.jgames.content, data)
					console.log('notice: content not in local storage - content imported from JSON file on the server side')
					def.resolve()
			
				}).fail(function() {	
					error(function_name, 'error', 'content file not found or unreadable')	
				})
			}
			else {
			
				$.jgames.content = $.extend({}, $.jgames.content, data)
				console.log('notice: content imported from local storage')
				def.resolve()	
			}
		}
	
		return def.promise()
	
	}
	
	$.jgames.exportcontent = function(options) {

		var function_name = '$.jgames.exportcontent'
	
		var def = $.Deferred();
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
	
		// mandatory
		if(opts['global_content'] == false && check(opts['subject']).primary !== 'integer') {
		
			error(function_name, 'error', 'subject not set or invalid')
			return 
		}
		else if(opts['global_content'] == false && check(opts['group']).primary !== 'integer') {
		
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['file']).primary !== 'string') {
		
			error(function_name, 'error', 'file not set or invalid')
			return 	
		}
	
		// get ID
		if(opts['global_content'] == false)	var ID = opts['file'] + "_" + opts['subject'] + "_" + opts['group'] + "_content"
		else 	var ID = opts['file'] + "_content"
			
		//console.log(ID)
			
		// save cookie
		if(opts['export_method'] == 'cookie') {
		
			var stringObj = JSON.stringify($.jgames.content)
			if(setCookie(stringObj, 1, ID))	console.log('notice: content-cookie created (valid for one day)')
			def.resolve()
		}
	
		// save file on server
		else if(opts['export_method'] == 'server') {
					
			$.ajax({
				method: "POST",
				url: opts['plugin_path'] + "php/database.writedefaults.php",
				data: { json: JSON.stringify($.jgames.content), ID: ID }
			}).done(function(data) {
			
				console.log('notice: content-file created')
				def.resolve()
			
			}).fail(function() {				
				error(function_name, 'error', 'content file could not be created - check for permission problem or wrongly specified path/filename')	
			})
	
		}
	
		// save using HTML5 localstorage
		else if(opts['export_method'] == 'client') {
		
			if(typeof(Storage) !== "undefined") {
				localStorage.setItem(ID, JSON.stringify($.jgames.content))
				console.log('notice: content-storage created')
				def.resolve()
			}
			else {
				error(function_name, 'error', 'content file could not be created - no HTML5 local storage support?')	
			}
		}		
	
	
		return def.promise()
	
	}
	
	
	$.jgames.addbehavior = function(options) {
		
		var function_name = '$.jgames.addbehavior'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round not set or invalid')
			return 	
		}
		else if(check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage not set or invalid')
			return 	
		}
		else if(check(opts['responses']).primary !== 'integer') {
			
			error(function_name, 'error', 'responses not set or invalid')
			return 	
		}	
		// optional
		else if(typeof opts['condition'] !== 'undefined' && check(opts['condition']).primary !== 'string') {
			
			error(function_name, 'error', 'condition invalid')
			return 			
		}
		else if(typeof opts['type'] !== 'undefined' && check(opts['type']).primary !== 'string') {
			
			error(function_name, 'error', 'type invalid')
			return 			
		}
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 			
		}
		else if(typeof opts['RT'] !== 'undefined' && check(opts['RT']).primary !== 'numeric' && check(opts['RT']).primary !== 'integer') {
			
			error(function_name, 'error', 'RT invalid')
			return 			
		}	
		
		var response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.addbehavior.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})

	    return response_promise
		
	}
	
	$.jgames.addearnings = function(options) {
		
		var function_name = '$.jgames.addearnings'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options	
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['stage'] !== 'undefined' && check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage invalid')
			return 				
		}
		else if(typeof opts['round'] !== 'undefined' && check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round invalid')
			return 				
		}
		else if(typeof opts['earnings'] !== 'undefined' && check(opts['earnings']).primary !== 'numeric' && check(opts['earnings']).primary !== 'integer') {
			
			error(function_name, 'error', 'earnings invalid')
			return 				
		}		
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 				
		}		
		
		response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.addearnings.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
		
	    return response_promise
		
	}
	
	$.jgames.addquestionnaire = function(options) {
		
		var function_name = '$.jgames.addquestionnaire'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
								
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(typeof opts['questions'] !== 'object') {
			
			error(function_name, 'error', 'questions not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 			
		}
		
		var response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.addquestionnaire.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})

	    return response_promise
		
	}
	
	$.jgames.readquestionnaire = function(options) {
		
		var function_name = '$.jgames.readquestionnaire'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['condition'] !== 'undefined' && check(opts['condition']).primary !== 'string') {
			
			error(function_name, 'error', 'condition invalid')
			return 				
		}
		else if(typeof opts['team'] !== 'undefined' && check(opts['team']).primary !== 'integer') {
			
			error(function_name, 'error', 'team invalid')
			return 				
		}		
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 				
		}		
		else if(typeof opts['subject'] !== 'undefined' && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.readquestionnaire.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
						
		return promised_data
		
	}
	
	$.jgames.addfinal = function(options) {
		
		var function_name = '$.jgames.addfinal'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
									
		// mandatory
		if(opts['finished'] !== 'TRUE' && opts['finished'] !== 'FALSE') {
			
			error(function_name, 'error', 'finished not set or invalid (must be either TRUE or FALSE)')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 			
		}
		
		var response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.addfinal.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})

	    return response_promise
		
	}
	
	$.jgames.addlog = function(options) {
		
		var function_name = '$.jgames.addlog'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round not set or invalid')
			return 	
		}
		else if(check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage not set or invalid')
			return 	
		}
		else if(check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 			
		}
		
		var response_promise = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.addlog.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})

	    return response_promise
		
	}
	
	
	$.jgames.readbehavior = function(options) {
		
		var function_name = '$.jgames.readbehavior'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round not set or invalid')
			return 	
		}
		else if(check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage not set or invalid')
			return 	
		}
		else if(check(opts['responses']).primary !== 'integer') {
			
			error(function_name, 'error', 'responses not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['condition'] !== 'undefined' && check(opts['condition']).primary !== 'string') {
			
			error(function_name, 'error', 'condition invalid')
			return 				
		}
		else if(typeof opts['type'] !== 'undefined' && check(opts['type']).primary !== 'string') {
			
			error(function_name, 'error', 'type invalid')
			return 				
		}
		else if(typeof opts['team'] !== 'undefined' && check(opts['team']).primary !== 'integer') {
			
			error(function_name, 'error', 'team invalid')
			return 				
		}		
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 				
		}		
		else if(typeof opts['subject'] !== 'undefined' && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject not set or invalid')
			return 	
		}
		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.readbehavior.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
						
		return promised_data
		
	}
		
	$.jgames.readearnings = function(options) {
		
		var function_name = '$.jgames.readearnings'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
				
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		else if(check(opts['aggregate']).primary !== 'boolean') {
			
			error(function_name, 'error', 'aggregate not set or invalid')
			return 				
		}
		// optional
		else if(typeof opts['subject'] !== 'undefined' && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject invalid')
			return 				
		}
		else if(typeof opts['stage'] !== 'undefined' && check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage invalid')
			return 				
		}
		else if(typeof opts['round'] !== 'undefined' && check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round invalid')
			return 				
		}
		else if(typeof opts['team'] !== 'undefined' && check(opts['team']).primary !== 'integer') {
			
			error(function_name, 'error', 'team invalid')
			return 				
		}

		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.readearnings.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
		
		return promised_data
		
	}
	
	$.jgames.readfreegroups = function(options) {

		var function_name = '$.jgames.readfreegroups'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		// optional
		else if(check(opts['max_groups']).primary !== 'integer') {
			
			error(function_name, 'warning', 'max_groups invalid or not set - set to 100')
			opts['max_groups'] = 100		
		}
		else if(typeof opts['condition'] !== 'undefined' && check(opts['condition']).primary !== 'string') {
			
			error(function_name, 'error', 'condition invalid')
			return 			
		}
		else if(typeof opts['type'] !== 'undefined' && check(opts['type']).primary !== 'string') {
			
			error(function_name, 'error', 'type invalid')
			return 			
		}
		else if(typeof opts['comment'] !== 'undefined' && check(opts['comment']).primary !== 'string') {
			
			error(function_name, 'error', 'comment invalid')
			return 			
		}
		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.freegroups.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}
		})
		
		return promised_data
		
	}
	
	$.jgames.getstatus = function(options) {
		
		var function_name = '$.jgames.getstatus'
				
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
				
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		// optional
		else if(typeof opts['subject'] !== 'undefined' && check(opts['subject']).primary !== 'integer') {
			
			error(function_name, 'error', 'subject invalid')
			return 				
		}
		else if(typeof opts['stage'] !== 'undefined' && check(opts['stage']).primary !== 'integer') {
			
			error(function_name, 'error', 'stage invalid')
			return 				
		}
		else if(typeof opts['round'] !== 'undefined' && check(opts['round']).primary !== 'integer') {
			
			error(function_name, 'error', 'round invalid')
			return 				
		}
		else if(typeof opts['team'] !== 'undefined' && check(opts['team']).primary !== 'integer') {
			
			error(function_name, 'error', 'team invalid')
			return 				
		}
		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.getstatus.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}	
		})
		
		return promised_data
		
	}
	

	$.jgames.timerstart = function(options) {
		
		start = new Date().getTime()
		return start
	}
	
	$.jgames.timerstop = function(options) {
		
		var elapsed = Math.round((new Date().getTime() - start)/10)/100
		start = 0.0
		console.log(elapsed)
		
		return elapsed
	}
	
	$.jgames.timerget = function(options) {
		
		var elapsed = Math.round((new Date().getTime() - start)/10)/100
		console.log(elapsed)
		
		return elapsed
	}
		
	
	$.jgames.getinput = function(options) {
				
		var function_name = '$.jgames.getinput'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['get']).primary !== 'string') {
			
			error(function_name, 'error', 'get not set or invalid')
			return 
		}
				
		var content
		var input_exceptions = ['checkbox', 'radio']
		var output = { input: {}, errors: {}, error: false }
		var error_val = false
							
		if(typeof opts['get'] != 'object') 	opts['get'] = [opts['get']]
		
			
		for(var i = 0; i < opts['get'].length; i++) {
			
			if($('[name="' + opts['get'][i] + '"]').length == 0) 	error(function_name, 'error', 'input element with name ' + opts['get'][i] + ' does not exist')
							
			if(isInArray($('[name="' + opts['get'][i] + '"]').prop('type'),input_exceptions))	content = $('input[name="' + opts['get'][i] + '"]:checked').val()
			else 	content = $('[name="' + opts['get'][i] + '"]').val()
			
			if(opts['output'] == 'int') output.input[opts['get'][i]]  = parseInt(content)
			else if(opts['output'] == 'float')	output.input[opts['get'][i]]  = parseFloat(content)
			else output.input[opts['get'][i]]  = content
						
			output.errors[opts['get'][i]]  = false
			//output.input.push(content)
			//output.errors.push(false)
						
			if(typeof opts['input' + (i+1)] !== 'undefined') {
				
				if(!isInArray(content, opts['input' + (i+1)]) && !isInArray(parseFloat(content), opts['input' + (i+1)])) {
					
					error_val = true
					//output.errors[i] = true
					output.errors[opts['get'][i]]  = true
					output.error = true
				}
			}
			else if(typeof opts['input'] !== 'undefined') {
				
				if(!isInArray(content, opts['input']) && !isInArray(parseFloat(content), opts['input'])) {
					
					error_val = true
					//output.errors[i] = true
					output.errors[opts['get'][i]]  = true
					output.error = true
				}
			}
		}
					
		if(error_val == true && opts['update_inputerror'] == true) {
			
			if(typeof this.content['error'] !== 'undefined') 	$("[name=error]").html(this.content['error'])
			else 	$("[name=error]").html("invalid input")	
				
			$("[name=error]").show()
		}
		else if(error_val == false && opts['update_inputerror'] == true) {
			
			$("[name=error]").html("")
		}
		
		
		return output
		
	}
	
	$.jgames.hideshow = function(options) {
		
		var function_name = '$.jgames.hideshow'
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		if(typeof opts['show'] != "object") 	opts['show'] = [opts['show']]
		if(typeof opts['hide'] != "object") 	opts['hide'] = [opts['hide']]
				
		for (var i = 0; i < opts['show'].length; i++) {
						
			if(opts['fade'] == true) 	$('[name="' + opts['show'][i] + '"]').fadeIn(opts['fading_speed'])
			else 	$('[name="' + opts['show'][i] + '"]').show()
		}
				
		for (var i = 0; i < opts['hide'].length; i++) {
			
			if(opts['fade'] == true) 	$('[name="' + opts['hide'][i] + '"]').fadeOut(opts['fading_speed'])
			else 	$('[name="' + opts['hide'][i] + '"]').hide()
		}
		
		return self
	}
		
	$.jgames.replace = function(options) {
		
		var function_name = '$.jgames.replace'	
		
		if(options === undefined) var opts = $.extend({}, this.content, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.content, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.content, options)
		else  var opts = options
							
		// mandatory
		if(check(opts['pattern']).primary !== 'string') {
			
			error(function_name, 'error', 'pattern not set or invalid')
			return 
		}
		else if(check(opts['element']).primary !== 'string') {
			
			error(function_name, 'error', 'element not set or invalid')
			return 	
		}
		else if(check(opts['replace']).primary !== 'string' && check(opts['replace']).primary !== 'integer' && check(opts['replace']).primary !== 'numeric') {
			
			error(function_name, 'error', 'replace not set or invalid')
			return 	
		}
		
		if(typeof opts['replace'] != "object") 	opts['replace'] = [opts['replace']]
				
		opts['pattern'] = opts['pattern'].replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&")
		var regex = new RegExp(opts['pattern'], 'g')
				
		var count_text = (opts[opts['element']].match(regex) || []).length
		var count_replace = opts['replace'].length
		
		
		if(count_text != count_replace) {
			
			error(function_name, 'warning', count_text + ' instances to be replaced in source file, but ' + count_replace + ' strings given for replacement')							
			while(count_replace < count_text) {
				
				opts['replace'] = opts['replace'].concat(opts['replace'])
				count_replace = opts['replace'].length
			}
		}
		
		var i = 0
		opts[opts['element']] = opts[opts['element']].replace(regex, function() { return String(opts['replace'][i++]); })
		
		this.content[opts['element']] = opts[opts['element']]
		
		
		return self
	}
	
	$.jgames.insert = function(options) {
		
		var function_name = '$.jgames.insert'
		
		if(options === undefined) var opts = $.extend({}, this.content, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.content, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.content, options)
		else  var opts = options
		
		// optional
		if(typeof opts['target'] !== 'undefined' && check(opts['target']).primary !== 'string')	{
			error(function_name, 'error', 'target invalid')
			return
		}	
		
		if(typeof opts['replacement'] !== 'undefined' && opts['target'] !== 'undefined') {
			
			if(typeof opts['replacement'] != "object") 	opts['replacement'] = [opts['replacement']]
			if(typeof opts['target'] != "object") 	opts['target'] = [opts['target']]
				
			if(opts['target'].length != opts['replacement'].length)	{
				error(function_name, 'error', "number of target elements does not match number of replacement elements")
				return
			}
								
			for(var val in opts['target']) {
				
				if($('[name="' + opts['target'][val] + '"]').length == 0) 	error(function_name, 'warning', "element with name '" + opts['target'][val] + "' does not exist")
				else 	$('[name="' + opts['target'][val] + '"]').html(opts['replacement'][val])
			}
			
		}
		else if(opts['target'] !== 'undefined') {
			
			if(typeof opts['target'] != "object") 	opts['target'] = [opts['target']]
			
			for(var val in opts['target']) {
							
				if(typeof opts[opts['target'][val]] === 'undefined') 	error(function_name, 'warning', "no content attached to the element with name '" + opts['target'][val] + "'")
				else if($('[name="' + opts['target'][val] + '"]').length == 0) 	error(function_name, 'warning', "element with name '" + opts['target'][val] + "' does not exist")					
				else 	$('[name="' + opts['target'][val] + '"]').html(opts[opts['target'][val]])
			}	
		}
		else {
			
			for(var key in opts) {
				if(opts.hasOwnProperty(key)) 	$('[name="' + key + '"]').html(opts[key])
			}
		}
		
		return self
				
	}
	
	
	$.jgames.drawobserver = function(options) {
		
		var function_name = '$.jgames.drawobserver'	
		
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		// optional
		if(opts['interval'] === undefined || check(opts['interval']).primary !== 'numeric' || check(opts['interval']).primary !== 'integer' || opts['interval'] < 500) {
			opts['interval'] = 4000
		}
		
		
		var loop = setInterval(function() {
		
			var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.drawobserver.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
				drawobserver(data)
			}	
		})
			return promised_data
		
		}, opts['interval'])
		
	}
	
	$.fn.drawselection = function(options) {
		
		var function_name = '$.jgames.drawselection'
		
		if(options === undefined) var opts = $.extend({}, $.jgames.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, $.jgames.defaults, options)
		else if(options.use_defaults == false) var opts = $.extend({}, $.jgames.defaults, options)
		else  var opts = options
										
		// mandatory
		if(opts['type'] == undefined) {
			
			error(function_name, 'error', 'type of selection not set or invalid')
			return 				
		}
		if(isInArray("subjects", opts['type']) && (check(opts['subjects']).primary !== 'integer')) {
			
			error(function_name, 'error', 'subjects not set or invalid')
			return 				
		}
		if(isInArray("groups", opts['type']) && (check(opts['free_groups']).primary !== 'integer' || check(opts['free_groups']).secondary !== 'array')) {
			
			error(function_name, 'error', 'free_groups not set or invalid')
			return 				
		}
		if(isInArray("teams", opts['type']) && (typeof opts['teams'] !== 'undefined' && (check(opts['teams']).primary !== 'integer' || check(opts['teams']).secondary === 'array'))) {
			
			error(function_name, 'error', 'teams invalid')
			return 				
		}
				
		return this.each(function() {
	
			var $this = $(this)
			
			if(isInArray("groups", opts['type'])) {
				
				$(this).append('group: &nbsp; <select name="group" class="input" id="group">')
				$(this).append('</select><br>')
							
				for(i = 0; i < opts['free_groups'].length; i++) { 
					$("[name = 'group']").append($('<option>', opts['free_groups'][i]).text(opts['free_groups'][i]))
				}			
			}
			
			if(isInArray("subjects", opts['type'])) {
				
				$(this).append('subject: &nbsp; <select name="subject" class="input" id="subject">')
				$(this).append('</select><br>')
							
				for(i = 1; i <= opts['subjects']; i++) { 
					$("[name = 'subject']").append($('<option>', i).text(i))
				}			
			}
			
			if(isInArray("teams", opts['type'])) {
				
				$(this).append('teams: &nbsp; <select name="team" class="input" id="team">')
				$(this).append('</select><br>')
							
				for(i = 1; i <= opts['teams']; i++) { 
					$("[name = 'team']").append($('<option>', i).text(i))
				}			
			}
					
			return self
						
		})	
	
	}
	
	$.fn.drawinput = function(options) {
		
		var function_name = '$.jgames.drawinput'
		
		if(options === undefined) var opts = $.extend({}, $.jgames.content, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, $.jgames.content, options)
		else if(options.use_defaults == false) var opts = $.extend({}, $.jgames.content, options)
		else  var opts = options
				
		var types = ['textarea', 'select', 'radio', 'button', 'checkbox', 'password', 'number', 'range', 'text', 'password']
		var range = ['number', 'range']
		var multiples = ['radio', 'checkbox']
		var content = ''
				
		// mandatory
		if(check(opts['html']).primary !== 'string') {
				
			if(check(opts['type']).primary !== 'string') {
				
				error(function_name, 'error', 'type not set or invalid')
				return 
			}
			if(!isInArray(opts['type'], types)) {
				
				error(function_name, 'error', 'type invalid')
				return 
			}
			if(typeof opts['value'] === 'undefined') {
				
				error(function_name, 'error', 'value undefined')
				return 			
			}
			if(typeof opts['label'] === 'undefined') {
				
				opts['label'] = fillArray('', opts['value'].length)		
			}
			else if(opts['label'].length !== opts['value'].length) {
				
				error(function_name, 'error', 'number of labels must match number of values')
				return 				
			}
		}
					
		if(typeof opts['description'] === 'undefined') 	opts['description'] = ''
		if(typeof opts['appendix'] === 'undefined')	opts['appendix'] = ''
		
	
		return this.each(function() {
	
			var $this = $(this)
			
			if(check(opts['html']).primary == 'string') {
				content = opts['html']
			}
			else {
				
				if(opts['format'] == 'list')	content = content + '<div class="' + opts['element_name'] + ' item">\n'
				if(opts['format'] == 'table')	content = content + '<tr>\n'
				
				// description
				if(opts['description'] != "") {
					
					if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' description">\n'
					if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' description">\n'
					content = content + '<span class="' + opts['element_name'] + ' description">' + opts['description'] + '</span>\n'
					if(opts['format'] == 'table')	content = content + '</td>\n'
					if(opts['format'] == 'list')	content = content + '</div>\n'
				}
				
				if(opts['type'] == 'textarea') {
					
					if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' cell1  cell">\n'
					if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' cell1  cell">\n'
            	
					content = content +  "<textarea name='" + opts['element_name'] + "'>" + opts['label'] + "</textarea>"
            	
					if(opts['format'] == 'table')	content = content + '</td>\n'
					if(opts['format'] == 'list')	content = content + '</div>\n'
				}				
				else if(opts['type'] == 'select') {
					
					if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' cell1 cell">\n'
					if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' cell1  cell">\n'
            	
					content = content + "<select name='" + opts['element_name'] + "'>\n"
            	
					if(typeof opts['value'] != "object") 	opts['value'] = [opts['value']]
					for(i = 0; i < opts['value'].length; i++) {
						content = content + "<option value='" + opts['value'][i] + "'>" + opts['label'][i] + "</option>\n"
					}
            	
					content = content + "</select>\n"
					if(opts['format'] == 'table')	content = content + '</td>\n'
					if(opts['format'] == 'list')	content = content + '</div>\n'	
					
				}
				else if(isInArray(opts['type'], multiples)) {
					
					if(typeof opts['value'] != "object") 	opts['value'] = [opts['value']]
					
					for(i = 0; i < opts['value'].length; i++) {
						
						if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' cell' + (i+1) + ' cell">\n'
						if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' cell' + (i+1) + ' cell">\n'
						
						content = content + "<input name='" + opts['element_name'] + "' value='" + opts['value'][i] + "' type='" + opts['type'] + "'> " + opts['label'][i] + " "
						
						if(opts['format'] == 'table')	content = content + '</td>\n'
						if(opts['format'] == 'list')	content = content + '</div>\n'	
					}
					
				}
				else {
					
					if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' cell1 cell">\n'
					if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' cell1 cell">\n'
            	
					content = content + "<input name='" + opts['element_name'] + "' value='" + opts['value'] + "' type='" + opts['type'] + "'"
					if(isInArray(opts['type'], range)) {
						if(typeof opts['min'] === 'undefined') 	opts['max'] = 0
						if(typeof opts['max'] === 'undefined') 	opts['max'] = 100
						if(typeof opts['step'] === 'undefined') 	opts['step'] = 1
						content = content + " min='" + opts['min'] + "' max='" + opts['max'] + "' step='" + opts['step'] + "'"
					}
					content = content + '>\n'
					
					if(opts['format'] == 'table')	content = content + '</td>\n'
					if(opts['format'] == 'list')	content = content + '</div>\n'
				}
				
				// appendix
				if(opts['appendix'] != "") {
				
					if(opts['format'] == 'list')	content = content + '<div class="' +  opts['element_name'] + ' appendix">\n'
					if(opts['format'] == 'table')	content = content + '<td class="' +  opts['element_name'] + ' appendix">\n'
					content = content + ' <span class="' + opts['element_name'] + ' appendix">' + opts['appendix'] + '</span>\n'	
					if(opts['format'] == 'table')	content = content + '</td>\n'
					if(opts['format'] == 'list')	content = content + '</div>\n'					
				}
				
				if(opts['format'] == 'table')	content = content + '</tr>\n'
				if(opts['format'] == 'list')	content = content + '</div>\n'
			}
				
			//console.log(content)
			$this.append(content)
	
		})
	}
		
		
	
	
	// PS specific
	
	$.jgames.rotate = function(options) {
		
		console.log(this.defaults.use_defaults)
		
		
		var function_name = '$.jgames.rotate'
		if(options === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
		else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
		else  var opts = options
			
		console.log(opts)
		
		// mandatory
		if(check(opts['name']).primary !== 'string') {
			
			error(function_name, 'error', 'name not set or invalid')
			return 
		}
		else if(check(opts['group']).primary !== 'integer') {
			
			error(function_name, 'error', 'group not set or invalid')
			return 	
		}
		
		var promised_data = $.ajax({
			method: "POST",
			url: opts['plugin_path'] + "php/database.rotate.php",
			dataType: "json",
			data: opts,
   			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
			success: function(data)	{
				if(data.error)	error(function_name, 'error', data.error)	
				else if(data.warning)	error(function_name, 'warning', data.warning)	
			}
		})
		
		return promised_data
				
	}
	
	
	
	// private variables / functions
	
	var start
	
	var self = this
	
	function error(source, type, message) {
		
		console.log(source)
		
		if(typeof message == 'object') {
			for (var i = 0; i < message.length; i++) {
		 	   console.log(type + ": " + message[i])
		 	   if($.jgames.defaults['show_errors'] == true)		alert(type + ": " + message[i])
			}
		}
		else {	
			console.log(type + ": " + message)
			if($.jgames.defaults['show_errors'] == true)	alert(type + ": " + message)
		}
		
		console.log('\n')
	}
	
	function check(variable) {
		
		var type = {};
		
		if(typeof variable == 'undefined') { type.primary = 'undefined' }
		else if(variable.constructor == Array)	{
			
			type.secondary = 'array'	
			type.length = variable.length
			
			if(arrayCheck(variable, 'integer')) type.primary = 'integer'
			else if(arrayCheck(variable, 'string')) type.primary = 'string'
			else if(arrayCheck(variable, 'numeric') || arrayCheck(variable, 'number')) type.primary = 'numeric'
			else if(arrayCheck(variable, 'boolean')) type.primary = 'boolean'
			else type.primary = 'unknown'			
		}
		else if(typeof variable === 'boolean') type.primary = 'boolean'
		else if(typeof variable === 'string') {
			if(isNaN(variable) == false & isInt(variable))  type.primary = 'integer'
			else if(isNaN(variable) == false) 	type.primary = 'numeric'
			else 	type.primary = 'string'
		}			
		else if(isInt(variable)) type.primary = 'integer'
		else if(typeof variable === 'numeric' || typeof variable === 'number') type.primary = 'numeric'
		else type = 'unknown'
			
		return type
	}
		
	function isInt(n) {
		
		
		
	   return n % 1 === 0
	}
	
	function arrayCheck(x, type) {
		
		for(var i = 0; i < x.length; i++) {
		   if(isNaN(x[i]) == false)	x[i] = Number(x[i]) 
		}
		//console.log(x)
		
		if(type == 'integer') 	return x.every(function(i) { return isInt(i)  })
		else 	return x.every(function(i) { return typeof i == type })	
	}
			
	function isInArray(value, array) {
		
	  return array.indexOf(value) > -1
	}
		
	function setCookie(value, exdays, name) {
				
		var d = new Date()
		d.setTime(d.getTime() + (exdays*24*60*60*1000))
		var expires = "expires=" + d.toUTCString()
		
		document.cookie = name + "=" + value + "; " + expires
		
		if(document.cookie)	return true
	}
	
	function getCookie(name) {
					
		var value = "; " + document.cookie
		var parts = value.split("; " + name + "=")
		
		if (parts.length == 2)	return parts.pop().split(";").shift()
	}
	
	function getQueryVariable(variable) {

	     var query = window.location.search.substring(1) 
	     var vars = query.split("&")

	     for(var i = 0; i < vars.length; i++) { 

	          var pair = vars[i].split("=")
	          if(pair[0] == variable) 	return unescape(pair[1])
	     } 
	     return false
	}
	
	function fillArray(value, len) {
	  
		if (len == 0) return []
		var a = [value]
		while (a.length * 2 <= len) a = a.concat(a)
		if(a.length < len) a = a.concat(a.slice(0, len - a.length))
		
		return a
	}
	
	function objectSize(obj) {
		
	    var size = 0, key;
		
	    for (key in obj) {
	        if (obj.hasOwnProperty(key)) size++
	    }
	    return size
	}
	
	function drawobserver(data) {
				
		jQuery("body").html("");
		$("head").append('<link rel="stylesheet" href="plugin/css/monitor.css" type="text/css">');
		
		content = "<div id='monitor'>" +
				"<table id='monitor'>" +
				"<tr>" +
					"<th id='monitor'>group</th>" +
					"<th id='monitor'>subject</th>" +
					"<th id='monitor'>team</th>" +
					"<th id='monitor'>round</th>" +
					"<th id='monitor'>comment</th>" +
					"<th id='monitor finished'>finished?</th>" +
				"</tr>"
		
		$("body").append(content)
		
		for (var group in data) {
		    if(data.hasOwnProperty(group)) {
				
				for (var subject in data[group]) {
					
					if (data[group].hasOwnProperty(subject)) {
						
						if(data[group][subject]['comment'] === undefined) data[group][subject]['comment'] = '-'						
						if(data[group][subject]['team'] === null) data[group][subject]['team'] = '-'						
						data[group][subject]['round'] = data[group][subject]['round'] + '/' + $.jgames.defaults.rounds	
						
						if(data[group][subject]['finished'] === undefined) {
							data[group][subject]['finished'] = 'no'
							fclass = 'waiting'					
						}
						else if(data[group][subject]['finished'] === 'FALSE') {
							data[group][subject]['finished'] = 'no'
							fclass = 'waiting'								
						}	
						else if(data[group][subject]['finished'] === 'TRUE') {
							data[group][subject]['finished'] = 'yes'
							fclass = 'finished'							
						}
													
						content = "<tr><td class='monitor'>" + group.replace("group", "") + "</td>" + 
									"<td class='monitor'>" + subject.replace("subject", "") + "</td>" +
									"<td class='monitor'>" + data[group][subject]['team'] + "</td>" +
									"<td class='monitor'>" + data[group][subject]['round'] + "</td>" +
									"<td class='monitor'>" + data[group][subject]['comment'] + "</td>" +
									"<td class='monitor " + fclass + "'>" + data[group][subject]['finished'] + "</td></tr>"
						
							
						$("table#monitor").append(content)
					}					
				}
		    }
		}
		
		$("table#monitor").append("</table>")
		$("table#monitor").append("</div>")
		
		console.log('monitor updated.')
	}
	
	
	
	
	$(document).ready(function() {
		
		// block keys, right click and delete as back button
		
		blockedkeys = [17,18,112,91,92,116]
		$('html').bind('keydown', function(e) {
			
			//console.log(e.keyCode)
			//console.log(e.which)
			for (i = 0; i < blockedkeys.length; i++) { 
				key = blockedkeys[i]
				if(e.which == key) 	event.preventDefault()
			}
			
			if(event.ctrlKey && event.keyCode == 82) { 
				event.preventDefault(); 
			}
		})		
		
	    $("html").on('contextmenu',function() {
	       return false
	    })
		
		// Prevent the backspace key from navigating back.
		$(document).unbind('keydown').bind('keydown', function (event) {
			
		    var doPrevent = false
		    if (event.keyCode === 8) {
				
		        var d = event.srcElement || event.target
				
		        if ((d.tagName.toUpperCase() === 'INPUT' && 
		             (
		                 d.type.toUpperCase() === 'TEXT' ||
		                 d.type.toUpperCase() === 'PASSWORD' || 
		                 d.type.toUpperCase() === 'FILE' || 
		                 d.type.toUpperCase() === 'SEARCH' || 
		                 d.type.toUpperCase() === 'EMAIL' || 
		                 d.type.toUpperCase() === 'NUMBER' || 
		                 d.type.toUpperCase() === 'DATE' )
		             ) || 
		             d.tagName.toUpperCase() === 'TEXTAREA') {
		            doPrevent = d.readOnly || d.disabled
		        }
		        else {
		            doPrevent = true
		        }
		    }

		    if (doPrevent) {
		        event.preventDefault()
		    }
		})
				
						
		$.ajaxSetup({ cache: false })
		
		$(":button").hover(
			function() {
			$(this).addClass('button-active')               
			},
			function() {
			$(this).removeClass('button-active')
		})
		
	})
	
	
		
}(jQuery))


//
//$.jgames.load = function(options) {
//	
//	var function_name = '$.jgames.load'
//	
//	if(options === undefined) var opts = $.extend({}, this.defaults, options)
//	else if(options.use_defaults === undefined) var opts = $.extend({}, this.defaults, options)
//	else if(options.use_defaults == true) var opts = $.extend({}, this.defaults, options)
//	else  var opts = options
//	
//	// mandatory
//	if(opts['type'] !== 'json' && opts['type'] !== 'file') {
//		
//		error(function_name, 'error', 'type not set or invalid')
//		return 
//	}
//	else if(opts['type'] === 'file' && check(opts['element']).primary !== 'string') {
//		
//		error(function_name, 'error', 'element not set or invalid')
//		return 			
//	}
//	else if(check(opts['file']).primary !== 'string') {
//		
//		error(function_name, 'error', 'file not set or invalid')
//		return 	
//	}
//			
//	
//	var def = $.Deferred()
//	
//	if(opts['type'] == 'json') {
//		
//		$.getJSON(opts['file'] + '.json', function(data) {	
//			$.jgames.content = $.extend({}, this.content, data)
//			def.resolve()
//		});
//	}
//	else if(opts['type'] == 'file') {
//		
//		$.ajax({
//			url: opts['file'] + "." + opts['load_extension'],
//			dataType: "html",
//			error: function(XMLHttpRequest, textStatus, errorThrown) {	error(function_name, 'error', errorThrown) 	},
//			success: function(data) {	$.jgames.content[opts['element']] = data; def.resolve();	},
//			statusCode: {	404: function() {	error(function_name, 'error', 'file not found at' + opts['file'])	}	}
//		});
//	}
//	
//	return def.promise() 
//			
//}
//