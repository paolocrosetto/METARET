README 
------
experiment script - risky helping
------


GENERAL INFO
------------

The experiment is programmed in HTML, JavaScript (jQuery), and PHP 5.6.
Data is stored in a mySQL database.


HOW TO RUN THE EXPERIMENT ON YOUR COMPUTER
------------------------------------------

STEP 1: INSTALL A LOCAL SERVER

To run the experiment locally, a local Apache server and a mySQL database need to be installed.
The easiest way to install a local server is to install a local server environment using the following free and open source solution stacks:

– MAMP (Mac OSX)
https://www.mamp.info/en/
– WAMP (Windows)
http://www.wampserver.com/en/
– XAMP (Linux)
https://www.apachefriends.org/


STEP 2: PLACE FILES TO THE DOCUMENT ROOT OF THE SERVER

After installation, all files need to be placed in the document root of the server.
The document root refers to a local folder on the hard-drive and can be found and changed in the preferences of the server software.


STEP 3: MODIFY THE LOCAL MYSQL ACCESS DATA

In order to run the experiment, the PHP-scripts need to have access to the local MySQL database.
1) Open the file /plugin/php/database.php.
2) Modify argument 5 and 6 on line 6.
3) Argument 5 specifies the user-name of the mySQL-database.
4) Argument 6 specifies the password for this user-name.
The password and user-name can be modified in the server settings (see documentation of the server).
The standard user-name and password configuration after installation is usually 'root', 'root' or 'root', '' (no password set). 


STEP 4: RUN THE EXPERIMENT

1) Start the server on your local machine.
The scripts were optimized for the Chrome browser. While they should run on any modern browser, using Chrome is highly recommended.
2) If the files were extracted to the document root of the server, navigate to http://localhost/
3) The index page should appear, that allows to select the experimental group, subject number, and condition.
4) To go through the entire experiment, each participant of one group needs to be selected in separate browser windows or tabs.


HOW TO RUN THE EXPERIMENT IN A LAB SETTING
------------------------------------------

In order to run the experiment in a lab environment, individual computers need to communicate with the server.
The server can be either set up locally over a local area network (LAN) or set up as a webserver and accessed over the internet.
To set up WAMP for local network access, see for example this tutorial: https://john-dugan.com/access-wamp-from-lan-computers/
