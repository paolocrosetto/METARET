library(multcomp)
library(lsr)
library(censReg)
library(crch)
library(latticeExtra)
library(Hmisc)
library(plm)
library(lmtest)


# 0 data

setwd('~') # change working directory

RH1 <- read.table('experiment1.csv', header=T)

RH1h <- RH1[RH1$role == 'helper',]
RH1v <- RH1[RH1$role == 'victim',]


setwd('~') # change working directory

print_results <- function(model) {
    
    res <- cbind(round(summary(model)$coefficients$location[,c(1)],2), round(summary(model)$coefficients$location[,c(4)],3))
    res <- res[!grepl('regular_medication', rownames(res)),]
    res[,2] <- paste(res[,1], ' (', res[,2], ')', sep='')
    res <- t(t(as.factor(res[,2])))
    res <- t(t(res[c(1,3,2,4:dim(res)[1]),]))
    
    return(res)
}

agg_switch <- function(x) if(is.factor(x) | is.character(x)) unique(x)[1] else mean(x)

plotprepare <- function(...) {
	
	par(bty='n', 
		cex=0.8,
		las=1, 
		ann=T, 
		lwd=2, 
		mar=c(5, 4, 2, 1), 
		oma=c(0,0,0,0), 
		pch=19, 
		xpd=T, 
		cex.axis=0.85, 
		mgp=c(2.5, 0.72, 0),
		tcl=-0.4, ...
		)
	
}

mypalette1 <- c("black", "#A1CAF1", "#81b4f0", "#f3313d", '#ffbd50', '#3ac1de', '#e4473d', '#fac751', '#02bed6', '#fdbd4b', '#cd0f20', '#365896')
webpalette5 <- c("#252839", "#677077", "#b5b5b7", "#f2b632")
rand <- c("#34b9d4", "#fcb969", "#ec4341", "#1e16f4", "#ff0013", "#00a7d4", "#558f4b", "#eeb449", "#e02735", "#f32431", "#353b92")

# end



# 0 age, gender

mean(RH1$age, na.rm=T)
sd(RH1$age, na.rm=T)

table(RH1$sex)

# end




# 0 analysis: decider

censModel1 <- crch(RH_switch ~ H_switch, data=RH1h, left = 0,  dist = "student")
censModel2 <- crch(RH_switch ~ R_switch, data=RH1h, left = 0,  dist = "student")
censModel3 <- crch(RH_switch ~ H_switch + R_switch, data=RH1h, left = 0,  dist = "student")
censModel4 <- crch(RH_switch ~ H_switch * R_switch, data=RH1h, left = 0,  dist = "student")

summary(glht(censModel3, linfct = c("H_switch - R_switch = 0")), test = adjusted("bonferroni"))


summary(censModel1)
summary(censModel2)
summary(censModel3)
summary(censModel4)

AIC(censModel1)
AIC(censModel2)
AIC(censModel3)
AIC(censModel4)

round(logLik(censModel1),2)
round(logLik(censModel2),2)
round(logLik(censModel3),2)
round(logLik(censModel4),2)

lrtest(censModel3, censModel1)
lrtest(censModel3, censModel2)

lrtest(censModel4, censModel3)
lrtest(censModel4, censModel2)
lrtest(censModel4, censModel1)


change <- RH1h$RH_switch - RH1h$H_switch
summary(lm(change ~ R_switch, data=RH1h))
cor.test(change,RH1h$R_switch, method='spearman')

change <- RH1h$RH_switch - RH1h$R_switch
summary(lm(change ~ H_switch, data=RH1h))
cor.test(change,RH1h$H_switch, method='spearman')

# end

# 0 analysis: receiver

censModel1_rec <- crch(RH_switch ~ H_switch, data=RH1v, left = 0,  dist = "student")
censModel2_rec <- crch(RH_switch ~ R_switch, data=RH1v, left = 0,  dist = "student")
censModel3_rec <- crch(RH_switch ~ H_switch + R_switch, data=RH1v, left = 0,  dist = "student")
censModel4_rec <- crch(RH_switch ~ H_switch * R_switch, data=RH1v, left = 0,  dist = "student")

wilcox.test(RH1v$H_switch, RH1h$H_switch)
wilcox.test(RH1v$RH_switch, RH1h$RH_switch)
wilcox.test(RH1v$R_switch, RH1h$R_switch)

# end

# 0 misc stats

wilcox.test(RH1h$H_switch, RH1h$RH_switch)
prop.table(table(RH1h$H_switch == 0))
prop.table(table(RH1h$RH_switch == 0))

mean(RH1h$H_switch)
mean(RH1h$RH_switch)

prop.table(table(c(RH1h$RHswitches, RH1h$Hswitches, RH1h$Rswitches) == 0))

prop.table(table(RH1h$RH_switch > 0.45))

prop.table(table(RH1h$R_switch > 0.45))
prop.table(table(RH1h$type3))

prop.table(table(RH1h$H_switch > 0))

cor.test(RH1h$H_switch, RH1h$R_switch, method='spearman')

# end

# 0 switch points

pdf('RH1 switchpoints.pdf', width=12, height=4.2)

plotprepare(mfrow=c(1,3), mar = c(5, 4, 3, 0.2), cex=1)

n <- seq(0,1,0.05)
x <- rep(0, length(n))
names(x) <- n
t <- prop.table(table(RH1h$R_switch))*100
x[names(x) %in% names(table(RH1h$R_switch))] <- t

b <- barplot(x, col=mypalette1[3], border=NA, space=0.03, ylim=c(0,40), xlab='', ylab='percentage observed')
lines(c(mean(b[c(10,11)]), mean(b[c(10,11)])), y = c(0,30), type = "l", col=mypalette1[4], lwd=0.8)
title(outer=FALSE, main="risk task", cex.main=1, col="black", font=2, line=1.2)

title(xlab='risk switching point')


n <- seq(0,1,0.05)
x <- rep(0, length(n))
names(x) <- n
t <- prop.table(table(RH1h$H_switch))*100
x[names(x) %in% names(table(RH1h$H_switch))] <- t

b <- barplot(x, col=mypalette1[3], border=NA, space=0.03, ylim=c(0,40), xlab='', ylab='')
lines(c(mean(b[c(10,11)]), mean(b[c(10,11)])), y = c(0,30), type = "l", col=mypalette1[4], lwd=0.8)
title(outer=FALSE, main="helping task", cex.main=1, col="black", font=2, line=1.2)

title(xlab='helping switching point')


n <- seq(0,1,0.05)
x <- rep(0, length(n))
names(x) <- n
t <- prop.table(table(RH1h$RH_switch))*100
x[names(x) %in% names(table(RH1h$RH_switch))] <- t

b <- barplot(x, col=mypalette1[3], border=NA, space=0.03, ylim=c(0,40), xlab='', ylab='')
lines(c(mean(b[c(10,11)]), mean(b[c(10,11)])), y = c(0,30), type = "l", col=mypalette1[4], lwd=0.8)

title(outer=FALSE, main="risky helping task", cex.main=1, col="black", font=2, line=1.2)
title(xlab='risky helping switching point')

dev.off()

# end

# 0 surface plot

x1 <- seq(0, 1, by=0.05)
x2 <- seq(0, 1, by=0.05)

newdata <- expand.grid(H_switch = x1, R_switch = x2, RH_switch = NA)
newdata$RH_switch <- predict(censModel3, newdata=newdata)
newdata <- aggregate(newdata, by=list(R_switch = newdata$R_switch, H_switch = newdata$H_switch), agg_switch)


colfunc <- colorRampPalette(c(mypalette1[4], mypalette1[3]))
cols <- colfunc(10)
cols <- c(cols, rep(cols[length(cols)],6))

trellis.device(pdf, file='RH1 surface plot.pdf', width=5, height=4.5)

p1 <- levelplot(RH_switch ~ R_switch + H_switch, data=newdata,
  xlab = expression('risk averse ' %<-% '' %->% ' risk seeking     '), ylab = "social preference (extent of helping)", ylab.right = list("predicted extent of risky helping", cex=0.8),
  main = "",
  par.settings = list(layout.widths = list(axis.key.padding = 0, ylab.right = 2.7)),
  scales=list(x=list(at=seq(0,1,0.1), labels=seq(0,1,0.1)), y=list(at=seq(0,1,0.1), labels=seq(0,1,0.1)), tck = c(1,0)),
  col.regions = cols, contour=F,
  colorkey=list(labels=list(at=seq(0,1,0.2),labels = seq(0,1,0.2)))
)

p1

trellis.focus("panel", 1, 1, highlight=FALSE)
lpoints(RH1h$R_switch, RH1h$H_switch, pch=16, col=rgb(0,0,0,0.4), cex=1)
trellis.unfocus()

dev.off()

# end

# 0 welfare increase

sacrifice <- 15 - RH1h$RH_EV_me[RH1h$type2 != 'pure selfish']
welfare_increase <- RH1h$RH_EV_group[RH1h$type2 != 'pure selfish'] - 15

mean(sacrifice) * 1.2965
mean(welfare_increase) * 1.2965

wilcox.test(sacrifice, welfare_increase, paired=T)
cohensD(sacrifice, welfare_increase, method = "paired")

means <- c(0,mean(sacrifice), mean(welfare_increase))
sems <- c(NA,sem(sacrifice), sem(welfare_increase))

names(means) <- c('', 'earning sacrifice', 'social welfare')
col <- c(mypalette1[3], mypalette1[4])

# end

# 0 guesses

col <- c(webpalette5[2], mypalette1[3])

pdf('RH1 victim vs helper.pdf', width=6.6, height=3)

plotprepare(mfrow=c(1,3), mar = c(2, 4, 3, 0.2), cex=1)

means <- c(0, mean(RH1h$R_switch), mean(RH1v$R_switch, na.rm=T))
sems <- c(NA, sem(RH1h$R_switch), sem(RH1v$R_switch, na.rm=T))

x <- barplot(means, col=col, border=NA, beside=T, ylim=c(0,0.5), xpd=F, ylab='switching point', width=c(0.1,1,1), names.arg = c('', 'helper', 'receiver'))
errbar(as.vector(x), c(means), means + sems, means - sems, add=T, xlab="", type='n', cap=0.05)

means <- c(0, mean(RH1h$H_switch), mean(RH1v$H_switch))
sems <- c(NA, sem(RH1h$H_switch), sem(RH1v$H_switch))

x <- barplot(means, col=col, border=NA, beside=T, ylim=c(0,0.5), xpd=F, ylab='', width=c(0.1,1,1), names.arg = c('', 'helper', 'receiver'))
errbar(as.vector(x), c(means), means + sems, means - sems, add=T, xlab="", type='n', cap=0.05)

means <- c(0, mean(RH1h$RH_switch), mean(RH1v$RH_switch))
sems <- c(NA, sem(RH1h$RH_switch), sem(RH1v$RH_switch))

x <- barplot(means, col=col, border=NA, beside=T, ylim=c(0,0.5), xpd=F, ylab='', width=c(0.1,1,1), names.arg = c('', 'helper', 'receiver'))
errbar(as.vector(x), c(means), means + sems, means - sems, add=T, xlab="", type='n', cap=0.05)

dev.off()

# end

# 0 monotonicity controls - main models

table(RH1h$R_nonmono)
table(RH1h$H_nonmono)
table(RH1h$RH_nonmono)


censModel1 <- crch(RH_switch ~ R_switch, data=RH1h[RH1h$RH_nonmono == F & RH1h$H_nonmono == F & RH1h$R_nonmono == F,], left = 0,  dist = "student")
censModel2 <- crch(RH_switch ~ H_switch, data=RH1h[RH1h$RH_nonmono == F & RH1h$H_nonmono == F & RH1h$R_nonmono == F,], left = 0,  dist = "student")
censModel3 <- crch(RH_switch ~ H_switch + R_switch, data=RH1h[RH1h$RH_nonmono == F & RH1h$H_nonmono == F & RH1h$R_nonmono == F,], left = 0,  dist = "student")
censModel4 <- crch(RH_switch ~ H_switch * R_switch, data=RH1h[RH1h$RH_nonmono == F & RH1h$H_nonmono == F & RH1h$R_nonmono == F,], left = 0,  dist = "student")

summary(censModel1)
summary(censModel2)
summary(censModel3)
summary(censModel4)

round(AIC(censModel1),2)
round(AIC(censModel2),2)
round(AIC(censModel3),2)
round(AIC(censModel4),2)

round(logLik(censModel1),2)
round(logLik(censModel2),2)
round(logLik(censModel3),2)
round(logLik(censModel4),2)


lrtest(censModel3, censModel1)
lrtest(censModel3, censModel2)
lrtest(censModel3, censModel4)

# end

# 0 order effects

R_positionRH1 <- ifelse(RH1h$order %in% c('R H RH', 'R RH H'), 0,
              ifelse(RH1h$order %in% c('H R RH', 'RH R H'), 1,
              ifelse(RH1h$order %in% c('RH H R', 'H RH R'), 2, NA
              )))

H_positionRH1 <- ifelse(RH1h$order %in% c('H R RH', 'H RH R'), 0,
              ifelse(RH1h$order %in% c('RH H R', 'R H RH'), 1,
              ifelse(RH1h$order %in% c('RH R H', 'R RH H'), 2, NA
              )))

RH_positionRH1 <- ifelse(RH1h$order %in% c('RH R H', 'RH H R'), 0,
               ifelse(RH1h$order %in% c('H RH R', 'R RH H'), 1,
               ifelse(RH1h$order %in% c('H R RH', 'R H RH'), 2, NA
               )))

summary(crch(R_switch ~ R_positionRH1, data=RH1h, left = 0,  dist = "student"))
summary(crch(R_switch ~ order, data=RH1h, left = 0,  dist = "student"))

summary(crch(H_switch ~ H_positionRH1, data=RH1h, left = 0,  dist = "student"))
summary(crch(H_switch ~ order, data=RH1h, left = 0,  dist = "student"))

summary(crch(RH_switch ~ RH_positionRH1, data=RH1h, left = 0,  dist = "student"))
summary(crch(RH_switch ~ order, data=RH1h, left = 0,  dist = "student"))


# 0 regression results when controlling for order - RH1

censModel1 <- crch(RH_switch ~ H_switch + order, data=RH1h, left = 0,  dist = "student")
censModel2 <- crch(RH_switch ~ R_switch + order, data=RH1h, left = 0,  dist = "student")
censModel3 <- crch(RH_switch ~ H_switch + R_switch + order, data=RH1h, left = 0,  dist = "student")
censModel4 <- crch(RH_switch ~ H_switch * R_switch + order, data=RH1h, left = 0,  dist = "student")


summary(censModel1)
summary(censModel2)
summary(censModel3)
summary(censModel4)

AIC(censModel1)
AIC(censModel2)
AIC(censModel3)
AIC(censModel4)

round(logLik(censModel1),2)
round(logLik(censModel2),2)
round(logLik(censModel3),2)
round(logLik(censModel4),2)

lrtest(censModel3, censModel1)
lrtest(censModel3, censModel2)
lrtest(censModel4, censModel3)

# end


# end

# 0 outliers

aggregate(RH1h$R_switch, by=list(RH1h$H_switch >= 0.5), agg_switch)
wilcox.test(RH1h$R_switch ~ RH1h$H_switch >= 0.5)

aggregate(RH1h$H_RT, by=list(RH1h$H_switch >= 0.5), agg_switch)
wilcox.test(RH1h$H_RT ~ RH1h$H_switch >= 0.5)

RH1h[RH1h$RH_switch == 1,]
aggregate(RH1h$RH_RT, by=list(RH1h$RH_switch != 1), agg_switch)

# end

# 0 reaction time

cor.test(RH1h$RH_switch, RH1h$RH_RT, method='spearman')
cor.test(RH1h$H_switch,  RH1h$H_RT, method='spearman')
cor.test(RH1h$R_switch,  RH1h$R_RT, method='spearman')

cor.test(RH1h$RH_switch[RH1h$RH_switch != 0], RH1h$RH_RT[RH1h$RH_switch != 0])
cor.test(RH1h$H_switch[RH1h$H_switch != 0],   RH1h$H_RT[RH1h$H_switch != 0])
cor.test(RH1h$R_switch[RH1h$R_switch != 0],   RH1h$R_RT[RH1h$R_switch != 0])

# end


