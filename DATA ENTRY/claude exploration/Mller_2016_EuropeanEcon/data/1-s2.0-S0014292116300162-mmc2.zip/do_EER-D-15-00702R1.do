*non-parametric and parametric tests of the relation between beta and risk
spearman beta risk_eg
pwcorr beta risk_eg, sig

*non-parametric tests on gender differences in risk and beta
ranksum risk_eg, by(female)
ranksum beta, by(female)

*non-parametric and parametric tests of the relation between beta and risk (by gender)
spearman beta risk_eg if female==0
spearman beta risk_eg if female==1
pwcorr beta risk_eg  if female==0, sig
pwcorr beta risk_eg  if female==1, sig

*censored tobit regressions
tobit beta risk_eg, ll(-0.07499) ul(1)
tobit beta c.risk_eg##female, ll(-0.07499) ul(1)
tobit beta c.risk_eg##female age econ neurocitism extraversion openness agreeableness conscientiousness, ll(-0.07499) ul(1)

*OLS regressions
reg beta risk_eg
reg beta c.risk_eg##female
reg beta c.risk_eg##female age econ neurocitism extraversion openness agreeableness conscientiousness
